# Citation and Ref Traceability

## Goal

Make every material number and source-dependent conclusion in a synthesized trial report traceable to the exact selected disclosure that supports it. `Ref` labels identify supplied source texts; they do not represent independent trials, evidence grades, or chronology.

## Assigning Refs

Assign `Ref 1`, `Ref 2`, and so on once per selected source in input inventory order. Keep the assignment stable throughout extraction and drafting. Do not reorder Ref numbers to imply earlier or later evidence.

The report's timeline is ordered independently using clinical timing:

1. data cutoff;
2. follow-up;
3. explicit analysis milestone;
4. disclosure/publication date.

## Inline syntax

Use:

```text
[Ref 1]
[Ref 1; Ref 3]
```

Place the Ref immediately after the supported number, clause, or table value.

Good:

```text
中位 PFS 为 11.1 个月（95% CI 9.9-NE），对照组为 6.9 个月（95% CI 5.8-8.6），HR 0.60（95% CI 0.46-0.78；单侧 p<0.0001）。[Ref 1]
```

Good table cell:

```text
11.1 个月（95% CI 9.9-NE）[Ref 1]
```

Avoid a single citation at the end of a long paragraph containing numbers from several sources. Split the paragraph or cite each claim locally.

## Claims that require Refs

Always cite:

- trial phase, randomization, blinding, center count and geography;
- sample size, arm size, analysis population and denominator;
- age, sex, disease burden, biomarkers and other baseline figures;
- dose, schedule, cycles, treatment duration and maintenance;
- data cutoff, follow-up and event count;
- endpoint value, confidence interval, p-value and effect estimate;
- subgroup value and analysis status;
- adverse event count, percentage, grade, seriousness and relatedness;
- source-supported labels such as interim, final, prespecified or post hoc;
- statements that an endpoint met a boundary or that no new safety signal was reported;
- conclusions that rely on one or more particular supplied texts.

Pure synthesis labels such as “证据链得到加强” still need Refs when they depend on specific endpoint results. General methodological cautions do not need Refs.

## Duplicates and multi-source support

When two sources repeat the same analysis:

- cite the clearest or most complete source for the number;
- optionally cite both Refs when each materially contributes context;
- state in the source index that the sources share an analysis state;
- never describe the duplicate as independent confirmation.

When one sentence combines facts from different sources, attach the relevant Ref to each clause or use a combined citation only when both sources support the entire sentence.

## Source index

End every report with a `来源索引` table containing:

- Ref label;
- source-supported human-readable identifier;
- data cutoff, follow-up, or analysis scope;
- principal contribution to the synthesis;
- relation to other selected sources.

Never include technical correlation IDs, database/index names, runtime field names, retrieval traces, or internal file paths.

## Verification

Before delivery, scan every numeral in the report. A numeral used as clinical evidence must have a Ref in the same sentence, bullet, or table row/cell. Verify that each cited Ref actually contains the claimed value and context. Confirm that every selected source appears in the source index, including duplicate or unusable items.
