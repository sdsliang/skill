#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate-chart.py — 图表 JSON 产物自检（生成后必跑；失败即修复后重跑）

自 v0.12 起，图表产物从 HTML fragment 迁移为 chart-visualization-json 协议的
纯 JSON 文件（endpoint-bar.json / endpoint-line.json / evidence-timeline.json）。
本脚本是本地自研的轻量 JSON 结构校验器（不依赖 node/zod CLI），校验范围与
外部 chart-visualization-json skill 的 RENDERABLE 开放类型一致：
  type ∈ { line, bar, timeline }
结构原则对齐外部 zod schema：顶层为 meta 字段 + 类型专属 payload；
data 项用 label/value/group/description；timeline 额外用 time/content/weight。

用法:
  python3 validate-chart.py <file.json> [file.json ...]
  python3 validate-chart.py <dir>              # 递归扫描目录内 *.json
  cat chart.json | python3 validate-chart.py   # 从 stdin 读取

退出码: 0 = 全部通过; 1 = 存在错误; 2 = 用法错误
"""
import json
import os
import re
import sys

MAX_SIZE = 1 << 20  # 1 MiB（外部 skill / 可视化通道文件上限）

RENDERABLE_TYPES = ["line", "bar", "timeline"]

# 顶层 meta 字段（外部协议 META_FIELDS + data）
TOP_STR_FIELDS = {"title", "subTitle", "dataSource", "describe", "axisXTitle", "axisYTitle"}
TOP_NUM_FIELDS = {"width", "height"}
TOP_BOOL_FIELDS = {"group", "stack"}
TOP_STR_ENUM = {"theme", "direction"}  # 值域单独校验

# 扁平 data 行（line/bar 共用；data.js LabelValueRowSchema）
ROW_LINE_BAR = {"label": "string", "value": "number", "group": "string", "description": "string"}

# timeline data 行（timeline.js TimelineEventSchema）
ROW_TIMELINE = {
    "label": "string",
    "time": "string",       # 必填；未知写「时间未明」，不得猜测
    "group": "string",      # 可选，对应 legend[].key
    "weight": "number",     # 可选 number ≥ 0
    "content": "string",    # 可选，支持 \n 多行
    "description": "string",
}

LEGEND_SHAPES = {"circle", "empty-circle"}

# 不允许出现在 value 里的"非数字"字面量（应放 description / 正文表格）
VALUE_FORBIDDEN_RE = re.compile(r"%(?=[\s\]]|$)|NR\b|NE\b|未报告|不确定|—|–|-$", re.IGNORECASE)


def first_path_line(obj, problems):  # noqa: D401
    """错误信息带 JSON path 字符串即可，JSON 无行号。"""
    return obj


def check_row(prefix, row, allowed, is_timeline, problems):
    """校验单个 data 行：字段名 + 字段类型 + 必填。"""
    if not isinstance(row, dict):
        problems.append(f"{prefix}: data 项必须是对象，得到 {type(row).__name__}")
        return

    # 字段白名单（允许 drill: any 透传）
    extra = set(row) - (set(allowed) | {"drill"})
    if extra:
        problems.append(f"{prefix}: 未识别的字段 {sorted(extra)}（允许 {sorted(allowed)} 及 drill）")

    # 必填
    for req in ("label",) + (("time",) if is_timeline else ("value",)):
        if req not in row:
            problems.append(f"{prefix}: 缺少必填字段 '{req}'")

    # 类型与约束
    for field, kind in allowed.items():
        if field not in row:
            continue
        val = row[field]
        if kind == "string":
            if not isinstance(val, str):
                problems.append(f"{prefix}.{field}: 应为 string，得到 {type(val).__name__}")
        elif kind == "number":
            if isinstance(val, bool) or not isinstance(val, (int, float)):
                problems.append(f"{prefix}.{field}: 应为 number，得到 {type(val).__name__}")
            elif field == "weight" and val < 0:
                problems.append(f"{prefix}.{field}: weight 必须 ≥ 0")
            elif field == "value":
                if isinstance(val, float) and (val != val):  # NaN
                    problems.append(f"{prefix}.{field}: value 不能为 NaN")
                elif VALUE_FORBIDDEN_RE.search(str(val)) or str(val).strip() == "":
                    problems.append(f"{prefix}.{field}: value 只能放纯数字；"
                                    "“未报告/NR/NE/区间/带%字符串”请移入 description 或正文表格")


def validate_chart(config, problems):
    if not isinstance(config, dict):
        problems.append("顶层必须是 JSON 对象")
        return

    typ = config.get("type")
    if not isinstance(typ, str) or typ not in RENDERABLE_TYPES:
        problems.append(f"type 必须是可渲染类型之一 {RENDERABLE_TYPES}，得到 {typ!r}")
        return

    # 顶层 meta 字段类型
    for field in TOP_STR_FIELDS:
        if field in config and not isinstance(config[field], str):
            problems.append(f"顶层 {field}: 应为 string，得到 {type(config[field]).__name__}")
    for field in TOP_NUM_FIELDS:
        if field in config and (isinstance(config[field], bool)
                                or not isinstance(config[field], (int, float))):
            problems.append(f"顶层 {field}: 应为 number，得到 {type(config[field]).__name__}")
    for field in TOP_BOOL_FIELDS:
        if field in config and not isinstance(config[field], bool):
            problems.append(f"顶层 {field}: 应为 boolean，得到 {type(config[field]).__name__}")
    if "theme" in config and config["theme"] not in {"default", "academy", "dark"}:
        problems.append(f"顶层 theme: 应为 default/academy/dark，得到 {config['theme']!r}")
    if "direction" in config and config["direction"] not in {"horizontal", "vertical"}:
        problems.append(f"顶层 direction: 应为 horizontal/vertical，得到 {config['direction']!r}")

    # data 必填非空
    data = config.get("data")
    if not isinstance(data, list) or not data:
        problems.append(f"{typ}: data 必须是非空数组")
        return

    if typ in ("line", "bar"):
        for i, row in enumerate(data):
            check_row(f"{typ}.data[{i}]", row, ROW_LINE_BAR, is_timeline=False, problems=problems)
    elif typ == "timeline":
        for i, row in enumerate(data):
            check_row(f"timeline.data[{i}]", row, ROW_TIMELINE, is_timeline=True, problems=problems)
        # legend / weightLegend
        legend = config.get("legend")
        if legend is not None:
            if not isinstance(legend, list):
                problems.append("timeline.legend: 应为数组")
            else:
                keys = set()
                for i, item in enumerate(legend):
                    if not isinstance(item, dict):
                        problems.append(f"timeline.legend[{i}]: 应为对象")
                        continue
                    if not isinstance(item.get("key"), str) or not item.get("key"):
                        problems.append(f"timeline.legend[{i}]: 缺少 key")
                    else:
                        keys.add(item["key"])
                    if not isinstance(item.get("label"), str):
                        problems.append(f"timeline.legend[{i}]: label 应为 string")
                    shape = item.get("shape")
                    if shape is not None and shape not in LEGEND_SHAPES:
                        problems.append(f"timeline.legend[{i}].shape: 应为 circle/empty-circle，得到 {shape!r}")
                for i, row in enumerate(data):
                    g = row.get("group")
                    if isinstance(g, str) and legend and g not in keys:
                        problems.append(f"timeline.data[{i}].group: '{g}' 未命中 legend key {sorted(keys)}"
                                        "（未命中时前端按默认实心圆处理，建议补齐图例项）")
        wl = config.get("weightLegend")
        if wl is not None:
            if not isinstance(wl, dict):
                problems.append("timeline.weightLegend: 应为对象")
            else:
                if "show" in wl and not isinstance(wl["show"], bool):
                    problems.append("timeline.weightLegend.show: 应为 boolean")
                if "label" in wl and not isinstance(wl["label"], str):
                    problems.append("timeline.weightLegend.label: 应为 string")


def validate(path):
    problems = []
    try:
        with open(path, encoding="utf-8") as fh:
            raw = fh.read()
    except Exception as e:  # noqa: BLE001
        print(f"   ✗ 无法读取文件: {e}")
        return False

    size = os.path.getsize(path)
    if size > MAX_SIZE:
        problems.append(f"文件过大 {size} B > 1 MiB（可视化通道上限）")

    try:
        config = json.loads(raw)
    except json.JSONDecodeError as e:
        problems.append(f"JSON 解析失败: {e.msg}（line {e.lineno} col {e.colno}）— "
                        "检查引号、逗号、括号；JSON 不支持注释")
        for p in problems:
            print("   ✗ " + p)
        return False

    validate_chart(config, problems)

    for p in problems:
        print("   ✗ " + p)
    return not problems


def main():
    args = sys.argv[1:]
    if not args:
        # stdin 模式
        raw = sys.stdin.read()
        try:
            config = json.loads(raw)
        except json.JSONDecodeError as e:
            print(f"   ✗ stdin JSON 解析失败: {e.msg}（line {e.lineno} col {e.colno}）")
            return 1
        problems = []
        validate_chart(config, problems)
        for p in problems:
            print("   ✗ " + p)
        if problems:
            return 1
        print("PASS  (stdin) type=%s" % config.get("type"))
        return 0

    files = []
    for p in args:
        if os.path.isdir(p):
            for root, _, fs in os.walk(p):
                for f in sorted(fs):
                    if f.lower().endswith(".json"):
                        files.append(os.path.join(root, f))
        else:
            files.append(p)
    if not files:
        print("未找到任何 .json 文件")
        return 2

    fails = 0
    for f in files:
        ok = validate(f)
        print(("PASS  " if ok else "FAIL  ") + f)
        fails += 0 if ok else 1
    print(f"\n共 {len(files)} 个文件，{fails} 个未通过")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
