# Cross-Trial Comparison

## Goal

Answer which selected result is stronger, weaker, or simply different without turning heterogeneous studies into a false league table.

## Step 1: Form clinical-question clusters

Cluster records using the clinical question, not disease name alone. Consider:

- intended condition or symptom;
- population and treatment setting;
- therapeutic objective;
- intervention role;
- outcome domain.

Examples within one disease may still require separate clusters for survival, symptom control, physical development, body composition, and long-term metabolic safety.

If two results answer different clinical questions, compare their evidence scope and relevance but do not declare one treatment clinically superior. Do not create a shared “efficacy winner” across clusters based on positivity, p-values, endpoint hierarchy, or narrative strength; those quantities answer different questions.

## Step 2: Build the research-key-field alignment

For every cluster, create one vertically stacked row per selected result and align:

- trial and registration identity;
- population and treatment setting;
- experimental intervention and regimen;
- within-study control or reference;
- design;
- experimental-arm sample and analysis set;
- endpoint hierarchy;
- time point/follow-up;
- efficacy and safety completeness.

The experimental regimen is the focal object. Keep the study's control visible because it affects internal validity, but do not treat controls from different studies as if they were a common comparator. Use `未报告` when absent. Do not replace a missing value with an inference.

## Step 3: Build the experimental-arm endpoint alignment

Create the report's primary outcome table with one row per `result + endpoint + population/time point`. Vertically stack the experimental arms across studies. Use these distinct columns:

- result label and clinical-question cluster;
- experimental regimen;
- endpoint, hierarchy, and definition;
- analysis population;
- experimental-arm observed result;
- within-study control and/or treatment-versus-control effect;
- time point/follow-up;
- endpoint alignment level;
- interpretation boundary.

Do not collapse the two result columns. An experimental-arm rate, median, or change is not the same object as a hazard ratio, least-squares difference, p-value, or qualitative statement versus control. If the experimental-arm observed value is not given, write `未报告（仅报告研究内比较效应）`. If no comparator exists or is reported, write `无/未报告` in the within-study context column.

This table is a non-head-to-head longitudinal view: it permits scanning of how selected experimental arms performed in their own studies, but does not by itself support a winner.

## Step 4: Classify endpoint alignment

Assign one level for each attempted endpoint comparison:

- **Directly aligned**: same clinical construct, materially compatible definition, population, statistic, and time frame.
- **Partially aligned**: same construct but one or more meaningful differences require caution.
- **Context only**: related domain but different endpoint definition, statistic, population, or timing prevents numeric comparison.
- **Not aligned**: different clinical question or no counterpart.

- **Directly aligned** and **Partially aligned** endpoints may support a bounded comparative direction after considering design and uncertainty.
- **Context only** and **Not aligned** endpoints must not produce a leader, directional winner, or raw-number ranking. Report the values only inside their own source contexts.

## Step 5: Judge comparison confidence

Assess the comparison as a whole using observable properties rather than a fixed score:

- similarity of patient populations;
- compatibility of interventions and controls;
- study-design differences;
- endpoint alignment;
- timing/follow-up alignment;
- analysis maturity and statistical completeness;
- safety exposure and reporting completeness.

Use one label:

- **High comparability**: rare outside a head-to-head or closely matched design; supports a strong comparative statement.
- **Moderate comparability**: supports a cautious directional comparison.
- **Low comparability**: supports context-level observations only.
- **Not meaningfully comparable**: do not rank outcomes.

Cross-trial comparisons usually cannot establish treatment superiority even when comparability is moderate or high. State that distinction clearly.

## Step 6: Make dimension-specific judgments

For each sufficiently aligned dimension **within the same clinical-question cluster**, use one of the labels below. “Favored” and “directionally favored” are available only when endpoint alignment is Directly aligned or Partially aligned:

- **Result A is favored on this dimension**: the evidence supports a clear within-scope advantage.
- **Result A is directionally favored**: the observed signal points toward A, but indirectness or uncertainty prevents a firm claim.
- **No material difference demonstrated**: the supplied evidence does not establish a meaningful difference.
- **Cannot determine**: missing or incompatible evidence blocks judgment.

Always attach the reason and confidence. Do not rank a raw percentage or median without verifying endpoint direction and context. Default to a plain-language interpretation after the vertical table rather than an exhaustive pairwise matrix. Create pairwise `A vs B` rows only for a true head-to-head comparison reported by a selected source.

## Step 7: Decide whether an overall winner exists

An overall winner requires all of the following:

- the compared results address substantially the same clinical question;
- key populations and regimens are sufficiently compatible;
- at least one decision-relevant efficacy endpoint is directly or partially aligned;
- safety evidence is not missing in a way that could reverse the decision;
- findings are directionally coherent across the most important dimensions;
- the wording does not imply head-to-head proof when none exists.

If any condition fails, report no overall winner and provide the most decision-relevant dimension-specific conclusion instead. When the input contains multiple clinical-question clusters, report leaders only inside each cluster and use `不适用` for any cross-cluster efficacy winner.

## Required visible output

Every cross-trial cluster must contain, before prose interpretation:

1. a research-key-field alignment table with one row per result;
2. an experimental-arm endpoint alignment table with one row per result-endpoint.

Do not replace these tables with narrative summaries, timeline tables, or pairwise comparability matrices.

## Required deep-analysis topics

- what can be compared and why;
- what cannot be compared and why;
- efficacy signal and its maturity;
- safety signal and reporting completeness;
- study-design impact on confidence;
- source rhetoric versus supported conclusion;
- dimension-specific leader, if any;
- whether an overall winner is justified.
