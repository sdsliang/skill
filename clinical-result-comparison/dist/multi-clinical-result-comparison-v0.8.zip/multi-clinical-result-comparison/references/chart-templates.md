# 图表模板（charts/）使用说明

> 多临床结果对比 Skill 的三张图表模板，基于蓝紫色系自定义色板（靛蓝→紫），
> 纯 SVG/CSS/原生 JS 单文件 HTML，无外部依赖（离线可用、Tool Smith 沙箱内可运行）。
> 与 `templates/charts/` 下的 HTML 文件配套使用。

## 一、选型规则（与 SKILL.md 工作流一致）

| 场景 | 图表 | 模板文件 |
| --- | --- | --- |
| **同试验**证据链时间轴（≥2 个证据状态） | 时间轴（旗帜 + 证据链成熟度带） | `charts/evidence-timeline.html` |
| **混合/不同试验**，终点无时间维（ORR 等单值） | 柱状图（横向） | `charts/endpoint-bar.html` |
| **混合/不同试验**，终点有时间维（体重、PFS/OS 按时间点） | 折线图；仅一个时间点→自动单点模式 | `charts/endpoint-line.html` |

- 一个报告最多 1–2 张图：同试验 = 1 张时间轴；混合 = 1 张柱状或折线。
- 证据边界不变：数值/披露形式/时间顺序**只能来自 `source_full_text`**，不得从输入顺序推断。

## 二、模板怎么用

1. **复制**对应 HTML 文件为成品（不要直接改模板文件）。
2. **只改 `<script>` 里的 `CHART` 数据对象**（title/subtitle/source/events/bars/series…），渲染区代码一律不动。
3. 保存为 `xxx.html`，正文中用 `::visualization[标题]{path="/workspace/visualizations/xxx.html"}` **绝对路径**引用（workspace 文件 + 引用 通道），独占一行；图前后保留解释文字。
   - Tool Smith 交付：文件**先写入** `/workspace/visualizations/`，再引用；引用路径必须从 `/workspace/visualizations/` 开头。
   - 降级：接入方不支持时，正文保留文字结论 + 可下载链接。

### 交付路径契约（所有图表统一遵守）

- 引用一律用**绝对路径**：`::visualization[标题]{path="/workspace/visualizations/<文件名>.html"}`。不写相对路径（如 `path="xxx.html"` 或 `path="visualizations/xxx.html"`）。
- 路径必须位于 `/workspace/visualizations/` 下；禁止目录穿越（`..`）、反斜杠 `\`、以及 `/workspace/visualizations/` 前缀之外的任何路径。
- 文件名用 ASCII 小写字母、数字、连字符（如 `train2-evidence-timeline.html`、`orr-comparison-endpoint-bar.html`），不使用子目录。
- 引用必须出现在文件写入**之后**；HTML 文件上限 1 MiB。
- 文件必须是 **HTML fragment**（Tool Smith 用隔离 iframe 的 fragment 渲染器注入，规则与内联 widget 相同）：**不含** `<!doctype html>`、`<html>`、`<head>`、`<body>`、`<meta>`、`<title>` 等文档级包裹；只保留 `<style>` + 内容 + `<script>`。模板已按此格式提供，成品不得再加回文档包裹标签。
- 正文始终保留 fallback（文字结论 + 精确数值表 + 下载链接），接入方不支持可视化时仍能完整理解结论。
4. 数据填充约束：
   - `events[]`（时间轴模板）一条 = **一个证据状态**（同状态多篇披露合并为一节点，`note` 并列 `{{ref_n}}`），按来源支持的 数据截止→随访→分析里程碑→披露日期 排布（模板按数组顺序排布，不推断阶段/形式）。
   - `value` 只填原文数值；`ci` 填原文给出的置信区间；`note` 为可追溯的补充说明。
   - 引用保留：图下方 source 行写清数据来源，正文相应位置保留 `{{ref_n}}` 标记。

## 三、配色（蓝紫色系）

基准见 `charts/chart-tokens.css`（每个模板内联了同一套 `:root` 变量）：

- 主色：靛蓝 `#4f46e5` → 紫罗兰 `#7c3aed` → 紫 `#a855f7`（品牌渐变）。
- 系列色 `--c-s1..s6`：同族可辨识（多试验/多组）。
- 语义用明度/饱和度区分（里程碑灰紫 `#8b87ad`、更新强调 `#a855f7`），**不用红绿色**表好坏。
- 文字：深靛蓝墨 `#211b4d`；背景浅紫灰 `#f6f5fd`；网格 `#e6e3f4`。

**接入 Tool Smith 宿主注入时**：把每个模板 `:root` 里的 `--c-*` 整体替换为对应 `--viz-*` token（映射表见 `chart-tokens.css` 文件底部），图表代码本身无需改动。

## 四、与 lieflat-charts 的关系

- 当前三张模板为自建（蓝紫定制，先保证"好看 + 品牌一致"）。
- 需要更花哨的图型（分布、矩阵、网络、报告页）时，可基于
  `~/.agents/skills/lieflat-charts`（64 图型）的 gallery 模板扩展；
  颜色仍建议收敛到本文件色板或 `--viz-*` 注入，避免混用色系。
- 同试验时间轴无 lieflat 完全对口图型，以本模板为准。

## 五、当前版本边界

- 全部图表（同试验时间轴、混合/不同试验柱状与折线）统一走 HTML 模板 + `::visualization` 引用，随 v0.8 生效；不再输出 Mermaid。
- 证据边界不变：数值/披露形式/时间顺序只能来自 `source_full_text`。
