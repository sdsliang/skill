#!/usr/bin/env python3
"""Fail-closed validator for the delivered card list.

Run this **before** ``present_artifact``. It checks the things a human reviewer would
otherwise have to eyeball, and it checks them against the pool rather than against the
plan, so a card cannot be self-consistent and still fabricated.

Exit codes: 0 = clean, 3 = at least one FAIL (details on stdout).

Checks
  1. envelope shape, ``count`` == len(cards), **at most 10 cards per bucket** (30 total)
  2. every card has a non-empty ``title`` / ``summary`` / ``why``, and ``why`` earns its
     place: it must reach ``MIN_WHY_CHARS`` and not be a re-wrap of ``summary``
     -- the field is supposed to say what the result *means*, not repeat what was printed
  3. ``esid`` exists in the pool (no invented records)
  4. ``bucket`` is one of early|pivotal|failed
  5. ``lba`` is a real boolean and ``manual`` is true/false/null -- both must match
     the pool row (``manual`` is null on the platform, where ``featured`` cannot be
     selected; a card may not upgrade that to a claim)
  6. no placeholder text leaked (TODO/XXX/None/nan/{}/$VAR)
  7. ``summary`` carries at least one unit-bearing number
  8. every ``%`` / ``mo`` / ``HR`` / ``ORR`` figure in summary+why appears in that
     record's own text -- the anti-fabrication gate
  9. list size is within a sane band for a reading list
 10. ``score`` is a real 0-100 integer and ``score_parts`` sums to it -- the score
     is the reviewer's judgement, so this gate checks self-consistency, not merit
 11. ``coverage_notes`` states the two honest limits (``data_type`` undetermined,
     abstracts without p/HR) -- the JSON is what gets read next month, so a limit
     that lives only in the chat reply is a limit nobody will see
 12. ``listed_company`` is present on every card (``null`` when the sponsor is not
     listed or could not be verified) and, when present, carries name+ticker+
     exchange+a resolvable source URL -- identity, no price: v0.9 removed the quote
     fields because a meeting abstract's readout is not separable from the ticker's
     sector beta, so a per-card percentage was beta dressed as signal
 13. no price claim survives anywhere -- ``stock``, ``reaction``, ``change_pct``,
     ``excess_pct`` on the card or under ``listed_company`` all fail. v0.9 deleted the
     quote layer deliberately; this is the gate that keeps it deleted
 14. the report, when ``--report`` is given: frontmatter carries ``skills`` (with this
     skill named) / ``title`` / ``date`` / ``lang``; every ``{{ref_N}}`` has a
     ``citations.json`` entry and vice versa; each entry is exactly
     ``{title, link, paper_release_time_str}`` with an http(s) link and a bare date
 15. a card whose esid is *not* in the machine pools is only legal when it was
     promoted by the web-curation step (``promoted == "web"``); it is then verified
     against ``work/rows.json`` instead, since promotion exists precisely to reach
     records the mechanical screen cut
 16. **selection is the top-k of the judgements** (v0.11): inside one bucket you may
     not drop a ``keep`` that scores higher than the lowest card you kept. Every such
     skip has to be declared in ``editorial_overrides`` with a reason, because "why is
     the better-scored trial missing" is the question a reader asks first. Same-score
     ties are free to break either way.
"""

from __future__ import annotations

from collections import Counter

# The rubric from references/review-protocol.md §2.5. These are *ceilings*, not
# weights: the reviewer decides how much of each to award, and the only thing
# checked mechanically is that the parts add up to the total they claimed.
# v0.7: the machine pools feed a 15-per-bucket shortlist, then the web-curation step
# cuts to 10. The cap lives here because an uncapped list stops being a reading list.
PER_BUCKET_CAP = 10
TOTAL_CAP = 30
# A "why" that is shorter than this is a label, not a judgement. 60 Chinese chars is
# roughly two sentences -- enough for "unmet need -> what this readout changes".
MIN_WHY_CHARS = 60
LISTED_FIELDS = ("name", "ticker", "exchange", "source_url")
# v0.8: `09966.HK` + `exchange=HKEX` prints one fact twice; the ticker is the bare code,
# the exchange field is the market, and a tool keyed on (market, code) can only match that.
MARKET_SUFFIXES = (".HK", ".SH", ".SS", ".SZ", ".T", ".L", ".DE", ".PA", ".AS", ".SW")
PROMOTE_REASONS = ("web",)
# What a regression would look like. Kept as a literal list rather than a schema check
# because the point is to catch the *field coming back*, whatever shape it has.
PRICE_KEYS = ("stock", "reaction", "change_pct", "excess_pct", "bench_change_pct",
              "price_source")
BUCKETS = ("early", "pivotal", "failed")
SCORE_CAPS = {"evidence_strength": 30, "effect_size": 25, "clinical_impact": 25,
              "novelty": 10, "readout_maturity": 10}

# The two claims the deliverable itself must carry. Kept in sync with
# `evals/fact-check/facts.json` -> A-H1-two-honest-claims (that item audits a finished
# run; this one stops the run from being delivered in the first place).
COVERAGE_CLAIMS = {
    "data_type":
        r"(?s)(?=.*(?:data_?type|数据类型|首次/更新))"
        r"(?=.*(?:未判定|未知|无法判定|不确定|判不出|不猜))",
    # "no p or HR" gets written at least five ways across runs ("无 p 或 HR" /
    # "未列p或HR" / "没给 p 值或 HR"). The gate is for the fact, not the wording.
    "p_hr":
        r"(?s)(?=.*(?:覆盖|全量|完整|不代表|并非))"
        r"(?=.*(?:p\s*值?\s*(?:[或/、,和与]|and)\s*(?:HR|风险比)"
        r"|(?:HR|风险比)\s*(?:[或/、,和与]|and)\s*p\s*值?"
        r"|(?:未列|无|缺|未给出|没有|没给|不含)\s*p\s*值?))",
}

import argparse
import json
import os
import re
import sys
from typing import Any, Dict, List, Optional, Tuple

try:  # same directory; the CLI runs from scripts/
    import triage
except ImportError:  # pragma: no cover - packaged imports
    triage = None  # type: ignore[assignment]

BUCKETS = ("early", "pivotal", "failed")
PLACEHOLDERS = ("TODO", "TBD", "XXX", "FIXME", "None", "nan", "{{", "}}", "占位")

# Word-like placeholders must match as whole tokens. Substring matching flagged
# "mainte**nan**ce" and "fi**nan**ce" as leaked "nan", which would fail a perfectly
# good card -- a false positive here is worse than a missed one, because the gate
# is fail-closed and stops the whole run.
_WORD_PLACEHOLDERS = {ph for ph in PLACEHOLDERS if ph.replace("_", "").isalnum()}


def leaf_text(value: Any) -> str:
    """All scalar strings inside a card, never the JSON punctuation around them.

    Scanning ``json.dumps(card)`` for ``}}`` flags every card whose last key is a
    nested object -- i.e. the well-formed case. Placeholders live in leaves.
    """
    if isinstance(value, dict):
        return "\n".join(leaf_text(v) for v in value.values())
    if isinstance(value, (list, tuple)):
        return "\n".join(leaf_text(v) for v in value)
    if value is None or isinstance(value, bool):
        return ""
    return str(value)


def placeholder_hits(text: str) -> List[str]:
    hits = []
    for ph in PLACEHOLDERS:
        if ph in _WORD_PLACEHOLDERS:
            if re.search(rf"(?<![A-Za-z]){re.escape(ph)}(?![A-Za-z])", text):
                hits.append(ph)
        elif ph in text:
            hits.append(ph)
    return hits
# v0.10: the unit list is what decides whether a number is checked at all, so a
# missing unit is a silent hole -- exactly how `16.1 mo` slipped through as
# 「16 个月」 in v0.9.1. Oncology wrote in %/months; cardiology, diabetes,
# hepatology and neurology write in mmol/L, mg/dL, mL/min, U/L, IU/mL, mL,
# points, mmHg, events per 100 patient-years. Every unit listed here is checked;
# anything absent is not.
UNIT_PATTERN = (
    r"(?:%|个百分点|个月|月|周|天|小时|年|"
    r"mo|months?|weeks?|days?|hours?|years?|"
    r"mmol/L|μmol/L|umol/L|mg/dL|mg/L|g/L|g/dL|ng/mL|pg/mL|μg/mL|ug/mL|"
    r"IU/mL|U/L|copies/mL|log10|mL/min(?:/1\.73m2)?|mL/kg/min|mL|L|"
    r"kg|cm|mmHg|bpm|points?|分|次/年|events?/100)"
)
UNIT_NUM = re.compile(r"\d+(?:\.\d+)?\s*" + UNIT_PATTERN, re.I)
FIGURE = re.compile(r"\d+(?:\.\d+)?\s*" + UNIT_PATTERN, re.I)


# The citation entry schema the delivery gate enforces verbatim:
# `{title, link, paper_release_time_str}` -- nothing more, nothing less. The date is a
# bare `YYYY-MM-DD`; an empty string is allowed, a made-up timestamp is not. This used
# to live only in the platform-side verifier, which is how ESC/EASL 2026 shipped
# `{title, link}` entries: correct to the docs, rejected after delivery.
CITE_KEYS = ["link", "paper_release_time_str", "title"]
FRONTMATTER_KEYS = ("skills", "title", "date", "lang")


def _frontmatter(report: str) -> Tuple[Dict[str, str], str]:
    """Split a leading YAML block off the report. Values stay as raw strings."""
    m = re.match(r"^---\r?\n(.*?)\r?\n---\r?\n?", report, re.S)
    if not m:
        return {}, report
    head: Dict[str, str] = {}
    for line in m.group(1).splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        key, _, value = line.partition(":")
        head[key.strip()] = value.strip()
    return head, report[m.end():]


def check_report(report_path: str) -> Tuple[List[str], List[str]]:
    """Gate the delivered markdown the same way the platform verifier will.

    Runs before ``present_artifact`` because that call is terminal: a run whose report
    cites three sources but ships ``{title, link}`` entries reads fine and is refused
    afterwards, when nobody can edit it any more.
    """
    fails: List[str] = []
    notes: List[str] = []
    text = open(report_path, encoding="utf-8").read()
    head, body = _frontmatter(text)
    if not head:
        fails.append("report: no YAML frontmatter -- `skills` / `title` / `date` / "
                     "`lang` must be there for the host to pick a theme")
        return fails, notes
    for key in FRONTMATTER_KEYS:
        if not head.get(key):
            fails.append(f"report: frontmatter missing {key}")
    if "conference-result-triage" not in (head.get("skills") or ""):
        fails.append("report: frontmatter `skills` does not list "
                     "conference-result-triage")
    used = {int(x) for x in re.findall(r"\{\{ref_(\d+)\}\}", body)}
    declared = head.get("citations") or ""
    if not declared:
        if used:
            fails.append(f"report: cites {sorted(used)} but frontmatter has no "
                         f"`citations:` line")
        return fails, notes
    # `/workspace/output/citations.json` is a platform path. Locally the run directory
    # only mirrors it, so resolve the reference against the report's own folder first and
    # fall back to the raw value -- hard-coding one layout made the gate unreadable off
    # the platform (it looked for `output/output/citations.json`).
    rep_dir = os.path.dirname(os.path.abspath(report_path))
    rel = declared[len("/workspace/"):] if declared.startswith("/workspace/") else declared
    candidates = [declared, os.path.join(rep_dir, os.path.basename(rel)),
                  os.path.join(rep_dir, rel), os.path.join(os.path.dirname(rep_dir), rel)]
    path = next((c for c in candidates if os.path.isfile(c)), candidates[1])
    try:
        cites = json.load(open(path, encoding="utf-8"))
    except (OSError, ValueError) as e:
        fails.append(f"report: cannot read citations file {declared}: {e}")
        return fails, notes
    if not isinstance(cites, dict) or not cites:
        fails.append("report: citations file is empty or not an object")
        return fails, notes
    keyed = {int(k.split("_")[1]) for k in cites if re.fullmatch(r"ref_\d+", k)}
    for k in cites:
        if not re.fullmatch(r"ref_\d+", k):
            fails.append(f"citations: invalid reference key {k!r}")
    if used != keyed:
        fails.append(f"citations: markers={sorted(used)} entries={sorted(keyed)} "
                     f"missing={sorted(used - keyed)} unused={sorted(keyed - used)}")
    for k, v in sorted(cites.items()):
        if not isinstance(v, dict):
            fails.append(f"citations {k}: not an object")
            continue
        if sorted(v) != CITE_KEYS:
            fails.append(f"citations {k}: keys {sorted(v)} != {CITE_KEYS} "
                         f"-- the gate wants title + link + paper_release_time_str")
            continue
        if not all(isinstance(x, str) for x in v.values()):
            fails.append(f"citations {k}: every value must be a string")
        if not (v.get("title") or "").strip():
            fails.append(f"citations {k}: empty title")
        if not re.match(r"^https?://", v.get("link") or ""):
            fails.append(f"citations {k}: link is not an http(s) URL")
        stamp = v.get("paper_release_time_str") or ""
        if stamp and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", stamp):
            fails.append(f"citations {k}: paper_release_time_str={stamp!r} is not "
                         f"YYYY-MM-DD")
    notes.append(f"report: {len(keyed)} citation entries, markers in sync")
    return fails, notes


def load_pool(path: str) -> Dict[str, Dict[str, Any]]:
    pool = json.load(open(path, encoding="utf-8"))
    by_esid: Dict[str, Dict[str, Any]] = {}
    for b in BUCKETS:
        for item in pool["pools"][b]["items"]:
            esid = item.get("esid")
            if esid:
                by_esid[str(esid)] = dict(item, _bucket=b)
    return by_esid


def recompute_pool(by_rows: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Rebuild the candidate pools from rows.json with the shipped triage code.

    The membership question ("is this record allowed on the list?") is answered by
    code, not by whichever pool file was passed in. E2E #10 on ESC 2026 found the
    cheap bypass: the model appended 110 records it thought triage had wrongly cut
    to a hand-made ``pool_ext.json`` and passed *that* as ``--pool``; every check
    went green while the fact layer, which rebuilds from ``work/pool/pool.json``,
    failed on 9 unknown esids and 61 untraceable figures. A pool file is display
    metadata now; this function is the gate.
    """
    rows = []
    for esid, item in by_rows.items():
        row = dict(item)
        row["_id"] = esid
        rows.append(row)
    pool = triage.build_pools(rows)
    out: Dict[str, Dict[str, Any]] = {}
    for b in BUCKETS:
        for item in pool["pools"][b]["items"]:
            if item.get("esid"):
                entry = dict(item, _bucket=b)
                out[str(item["esid"])] = entry
                # Dedupe merged these esids into the entry above; a card written
                # off the sibling record is the same card (see triage.build_pools).
                for alias in item.get("alias_esids") or []:
                    out[str(alias)] = dict(entry, _alias_of=str(item["esid"]))
    return out


def load_judged(path: str) -> Dict[str, Dict[str, Any]]:
    """Per-item judgement records, keyed by esid.

    v0.11 requires ``esid`` on every judged entry. Before that the records carried
    only a batch-local ``i``, so "which record did the reviewer score 85" could only be
    answered by re-reading the batch file -- and a hand-made batch could answer it
    differently. An identity the *judgement* states is an identity the gate can hold
    it to, and ``selection_order`` is exactly that gate.
    """
    files: List[str] = []
    if os.path.isdir(path):
        files = [os.path.join(path, f) for f in sorted(os.listdir(path))
                 if f.startswith("judged") and f.endswith(".json")]
    elif os.path.exists(path):
        files = [path]
    out: Dict[str, Dict[str, Any]] = {}
    for f in files:
        payload = json.load(open(f, encoding="utf-8"))
        items = payload.get("items") if isinstance(payload, dict) else payload
        for item in items or []:
            if not isinstance(item, dict):
                continue
            # Only real judgement records: a `selected.json` or a plan file in the
            # same directory must not be mistaken for one (it carries esid but no
            # verdict), or the gate would read "nobody was judged keep" as "nothing
            # to compare" and pass on an empty set -- the classic empty-vs-empty trap.
            if item.get("verdict") is None or item.get("score") is None:
                continue
            esid = str(item.get("esid") or "").strip()
            if esid:
                out[esid] = item
    return out


def selection_order(cards: List[Dict[str, Any]], judged: Dict[str, Dict[str, Any]],
                    overrides: Any) -> Tuple[List[str], List[str]]:
    """A bucket list must be the top of its own ranking.

    E2E #11 (EASL 2026) shipped a 35-score pivotal card while a judged-85 PBC trial sat
    unused in the same bucket: every other gate was green, because they all ask "is what
    you listed legal", never "is what you listed better". The judgement layer already
    answered that -- this compares its answers against the delivered set.

    Overrides are a ledger, not a loophole: an entry without a readable reason does not
    count, so the only way past a higher-scored skip is to say why in the deliverable.
    """
    fails: List[str] = []
    notes: List[str] = []
    waived: Dict[str, str] = {}
    if overrides is not None:
        if not isinstance(overrides, list):
            fails.append("envelope: editorial_overrides must be a list")
        else:
            for entry in overrides:
                if not isinstance(entry, dict):
                    fails.append("envelope: editorial_overrides entries must be objects")
                    continue
                esid = str(entry.get("esid") or "").strip()
                reason = " ".join(str(entry.get("reason") or "").split())
                if not esid:
                    fails.append("envelope: editorial_overrides entry without esid")
                    continue
                if len(reason) < 10:
                    fails.append(f"envelope: editorial_overrides[{esid}] reason is "
                                 f"{len(reason)} chars -- say what made you skip it")
                    continue
                waived[esid] = reason
    kept = {str(c.get("esid") or ""): c for c in cards}
    by_bucket: Dict[str, List[Dict[str, Any]]] = {}
    for esid, item in judged.items():
        if str(item.get("verdict") or "").lower() != "keep":
            continue
        score = item.get("score")
        if not isinstance(score, int) or isinstance(score, bool):
            continue
        bucket = str(item.get("bucket") or "")
        by_bucket.setdefault(bucket, []).append(
            {"esid": esid, "score": score, "title": str(item.get("reason") or "")})
    if not by_bucket:
        fails.append("selection: not one judged record landed in a bucket -- the "
                     "judgement records need `esid` + `bucket` + `verdict` + `score` "
                     "(v0.11), otherwise the editorial step cannot be checked at all")
        return fails, notes
    for bucket, items in by_bucket.items():
        chosen = [c for e, c in kept.items() if str(c.get("bucket") or "") == bucket]
        if not chosen:
            notes.append(f"selection: bucket {bucket} kept nothing; nothing to compare")
            continue
        floor = min(int(c.get("score") or 0) for c in chosen)
        for item in sorted(items, key=lambda x: -x["score"]):
            if item["esid"] in kept or item["score"] <= floor:
                continue
            if item["esid"] in waived:
                notes.append(f"selection: {bucket} skipped {item['esid']} "
                             f"({item['score']} > floor {floor}) under a declared "
                             f"override")
                continue
            fails.append(
                f"selection: {bucket} kept a {floor}-score card while judged-keep "
                f"{item['esid']} scores {item['score']} -- take the higher one, or "
                f"declare it in editorial_overrides with a reason ({item['title'][:40]})")
    return fails, notes


def load_rows(path: str) -> Dict[str, Dict[str, Any]]:
    """Raw workspace rows, flattened exactly like ``triage.py`` does.

    Needed only for promoted cards: ``bucket_of``/``excluded_reason`` deliberately cut
    ~500 rows out of the pools, and the web step is allowed to bring one back.
    """
    payload = json.load(open(path, encoding="utf-8"))
    rows = payload.get("rows") if isinstance(payload, dict) else payload
    out: Dict[str, Dict[str, Any]] = {}
    for raw in rows or []:
        item = triage.flat_row(raw) if any(str(k).startswith(triage.PREFIXES) for k in raw) else dict(raw)
        esid = item.get("esid") or item.get("_id")
        if esid:
            out[str(esid)] = item
    return out


def record_text(item: Dict[str, Any]) -> str:
    """Everything the record itself claims, for the number-traceability check."""
    parts = [item.get("results"), item.get("results_text"), item.get("study_results"),
             item.get("key_evidence"), item.get("summary"), item.get("background"),
             item.get("primary_endpoint"), item.get("abstract_text")]
    flat: List[str] = []
    for p in parts:
        if isinstance(p, list):
            flat.extend(str(x) for x in p)
        elif p:
            flat.append(str(p))
    return " ".join(flat)


def check(payload: Dict[str, Any], by_esid: Dict[str, Dict[str, Any]],
          by_rows: Optional[Dict[str, Dict[str, Any]]] = None,
          by_calc: Optional[Dict[str, Dict[str, Any]]] = None,
          judged: Optional[Dict[str, Dict[str, Any]]] = None,
          ) -> Tuple[List[str], List[str]]:
    fails: List[str] = []
    notes: List[str] = []
    cards = payload.get("cards")
    if not isinstance(cards, list):
        return ["envelope: `cards` is not a list"], notes
    if payload.get("count") != len(cards):
        fails.append(f"envelope: count={payload.get('count')} != len(cards)={len(cards)}")
    if not payload.get("conference"):
        fails.append("envelope: missing conference")
    if not 10 <= len(cards) <= TOTAL_CAP:
        fails.append(f"size: {len(cards)} cards (expected a 10-{TOTAL_CAP} item reading list)")
    claims = payload.get("coverage_notes")
    if not isinstance(claims, list) or not claims:
        fails.append("envelope: `coverage_notes` missing -- the two honest limits "
                     "(data_type undetermined / abstracts without p or HR) must live "
                     "in the delivered JSON, not only in the reply")
    else:
        joined = "\n".join(str(x) for x in claims if str(x).strip())
        for name, pattern in COVERAGE_CLAIMS.items():
            if not re.search(pattern, joined):
                fails.append(f"envelope: coverage_notes does not state the {name} limit")

    per_bucket = Counter(c.get("bucket") for c in cards)
    for name, num in per_bucket.items():
        if name not in BUCKETS:
            fails.append(f"bucket: unknown bucket {name!r}")
        elif num > PER_BUCKET_CAP:
            fails.append(f"bucket {name}: {num} cards > cap {PER_BUCKET_CAP} "
                         f"-- cut by score, do not pad the list")

    if judged:
        sfails, snotes = selection_order(cards, judged,
                                        payload.get("editorial_overrides"))
        fails += sfails
        notes += snotes
    else:
        notes.append("selection: no judged records passed in -- the editorial hop "
                     "from judgement to list is unchecked (the CLI always passes "
                     "`--judged`, so this only happens in-process)")

    seen = set()
    for n, card in enumerate(cards, 1):
        tag = f"card {n} ({card.get('esid') or 'no-esid'})"
        esid = str(card.get("esid") or "")
        if not esid:
            fails.append(f"{tag}: empty esid")
            continue
        if esid in seen:
            fails.append(f"{tag}: duplicate esid")
        seen.add(esid)
        # Membership comes from the recomputed pools when rows.json was supplied;
        # the pool file only fills in display fields for records it happens to hold.
        item = (by_calc if by_calc is not None else by_esid).get(esid)
        origin = "pool"
        if item is None and by_rows:
            item = by_rows.get(esid)
            origin = "rows"
        if item is not None and origin == "pool":
            item = dict(item)
            item.setdefault("_bucket", (by_esid.get(esid) or {}).get("_bucket"))
        if item is None:
            fails.append(f"{tag}: esid not in pool")
            continue
        promoted = card.get("promoted")
        if promoted is not None and promoted not in PROMOTE_REASONS:
            fails.append(f"{tag}: promoted={promoted!r} not in {list(PROMOTE_REASONS)}")
        if origin == "rows":
            if promoted not in PROMOTE_REASONS:
                fails.append(f"{tag}: esid is outside the machine pools and was not "
                             f"promoted -- set promoted='web' and say why in `why`")
                continue
            notes.append(f"{tag}: promoted from rows.json (outside the candidate pools)")
        for key in ("title", "summary", "why"):
            if not str(card.get(key) or "").strip():
                fails.append(f"{tag}: missing {key}")
        if card.get("bucket") not in BUCKETS:
            fails.append(f"{tag}: bad bucket {card.get('bucket')!r}")
        elif item.get("_bucket") and card["bucket"] != item.get("_bucket"):
            notes.append(f"{tag}: bucket re-judged {item.get('_bucket')} -> {card['bucket']}")
        why = " ".join(str(card.get("why") or "").split())
        summary = " ".join(str(card.get("summary") or "").split())
        if why and len(why) < MIN_WHY_CHARS:
            fails.append(f"{tag}: why is {len(why)} chars (< {MIN_WHY_CHARS}) -- it must "
                         f"say what the result means, not label it")
        if why and summary and (summary[:20] in why or why[:20] in summary):
            fails.append(f"{tag}: why repeats summary -- state the value, not the numbers")
        if not isinstance(card.get("lba"), bool):
            fails.append(f"{tag}: lba must be boolean")
        elif card["lba"] != bool(item.get("lba")):
            fails.append(f"{tag}: lba={card['lba']} but pool row says {bool(item.get('lba'))}")
        # `manual` is a provenance claim (human-curated vs pipeline-extracted), so a
        # card that flips it is telling the reader the wrong thing about how the row
        # was produced. Optional key: older plans predate it and a missing key must
        # not fail -- but a present key must agree with the pool.
        if "manual" in card:
            if not isinstance(card["manual"], bool | None):
                fails.append(f"{tag}: manual must be boolean or null")
            elif card["manual"] != item.get("manual"):
                fails.append(f"{tag}: manual={card['manual']} but pool row says "
                             f"{item.get('manual')}")
        if "score" not in card:
            fails.append(f"{tag}: missing score (the review must judge every card)")
        else:
            score = card["score"]
            if not isinstance(score, int) or isinstance(score, bool) or not 0 <= score <= 100:
                fails.append(f"{tag}: score={score!r} must be an integer 0-100")
            parts = card.get("score_parts") or {}
            if parts:
                if set(parts) != set(SCORE_CAPS):
                    fails.append(f"{tag}: score_parts keys {sorted(parts)} != "
                                 f"{sorted(SCORE_CAPS)}")
                else:
                    for name, cap in SCORE_CAPS.items():
                        val = parts[name]
                        if not isinstance(val, int) or isinstance(val, bool) or not 0 <= val <= cap:
                            fails.append(f"{tag}: score_parts[{name}]={val!r} "
                                         f"must be an integer 0-{cap}")
                    if sum(parts.values()) != score:
                        fails.append(f"{tag}: score_parts sum {sum(parts.values())} "
                                     f"!= score {score}")
        body = leaf_text(card)
        for ph in placeholder_hits(body):
            fails.append(f"{tag}: placeholder {ph!r} leaked into the card")
        if not UNIT_NUM.search(str(card.get("summary") or "")):
            fails.append(f"{tag}: summary has no unit-bearing number")
        text = record_text(item)
        # Compare values, not substrings. `"44" in text` was true whenever the abstract
        # said 44.7% or n=144, so "12 个月 PFS 率 44% vs 24%" (a press-release figure the
        # abstract never printed) sailed through this gate while the offline fact layer
        # caught it. The two must agree, and this is the weaker side by design: the
        # delivered JSON has to fail before it is presented, not after.
        src_nums = {float(m.group(0)) for m in re.finditer(r"\d+(?:\.\d+)?", text)}
        for fig in sorted(set(FIGURE.findall(f"{card.get('summary')} {card.get('why')}"))):
            try:
                num = float(re.sub(r"[^\d.]", "", fig))
            except ValueError:
                continue
            if num not in src_nums:
                fails.append(f"{tag}: figure {fig!r} not found in the record text")
        for key in PRICE_KEYS:
            if key in card and card.get(key) not in (None, "", {}):
                fails.append(f"{tag}: {key} is a price field -- v0.9 removed the quote "
                             f"layer; the card is about the readout")
        # Presence of the key is the contract, not presence of a value: `null` means
        # "checked and not listed / not verifiable". A missing key silently means the
        # same thing without anybody having looked, which is the failure mode this
        # field exists to prevent.
        if "listed_company" not in card:
            fails.append(f"{tag}: missing listed_company (null when the sponsor is not "
                         f"listed or cannot be verified)")
            continue
        company = card["listed_company"]
        if company is None:
            continue
        if not isinstance(company, dict):
            fails.append(f"{tag}: listed_company must be an object or null")
            continue
        for key in LISTED_FIELDS:
            if not str(company.get(key) or "").strip():
                fails.append(f"{tag}: listed_company.{key} missing")
        url = str(company.get("source_url") or "")
        if url and not re.match(r"^https?://\S+$", url):
            fails.append(f"{tag}: listed_company.source_url is not an http(s) URL: {url!r}")
        ticker = str(company.get("ticker") or "")
        if ticker and not re.search(r"[0-9A-Za-z]", ticker):
            fails.append(f"{tag}: listed_company.ticker={ticker!r} has no alphanumerics")
        for key in PRICE_KEYS:
            if key in company and company.get(key) not in (None, "", {}):
                fails.append(f"{tag}: listed_company.{key} is a price field -- v0.9 keeps "
                             f"identity only; a meeting-day move is sector beta")
        hit = next((sfx for sfx in MARKET_SUFFIXES if ticker.upper().endswith(sfx)), None)
        if hit:
            fails.append(f"{tag}: listed_company.ticker={ticker!r} carries the market suffix "
                         f"{hit} while exchange={company.get('exchange')!r} -- the ticker holds "
                         f"the bare code, the exchange field holds the market")
    return fails, notes


def main(argv: List[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cards", required=True)
    ap.add_argument("--pool", required=True)
    ap.add_argument("--rows", required=True,
                    help="work/rows.json -- always required: the pool membership "
                         "gate is rebuilt from it, so a hand-edited pool file cannot "
                         "widen the candidate set")
    ap.add_argument("--judged", required=True,
                    help="work/judged_*.json (or their directory) -- every judged entry "
                         "needs an `esid` so the selection can be compared against the "
                         "scores the reviewer actually gave")
    ap.add_argument("--report", help="output/report.md -- also gate the markdown: "
                                     "frontmatter keys, `{{ref_N}}` <-> citations.json "
                                     "in both directions, and the exact entry schema")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    payload = json.load(open(args.cards, encoding="utf-8"))
    by_esid = load_pool(args.pool)
    by_rows = load_rows(args.rows)
    by_calc = recompute_pool(by_rows)
    judged = load_judged(args.judged)
    if not judged:
        # Fail closed: the path exists but nothing in it is usable. Passing here would
        # mean "nobody was judged keep", which is indistinguishable from "the check
        # never ran" -- and an unchecked editorial step is precisely what shipped the
        # EASL 2026 list with a 35-score card above an unused 85-score one.
        judged = None
        sel_fail = (f"selection: {args.judged} holds no usable judgement record "
                    f"(needs esid + bucket + verdict + score per entry)")
    (fails, notes) = check(payload, by_esid, by_rows, by_calc, judged)
    if judged is None:
        fails.append(sel_fail)
    if set(by_calc) != set(by_esid):
        notes.append(
            f"pool file holds {len(by_esid)} records, a fresh triage build over "
            f"rows.json gives {len(by_calc)} -- membership is judged on the rebuild, "
            f"so re-run triage.py instead of editing the pool by hand")
    if args.report:
        rfails, rnotes = check_report(args.report)
        fails += rfails
        notes += rnotes

    if notes and args.verbose:
        for n in notes:
            print(f"  note: {n}")
    if fails:
        print(f"FAIL ({len(fails)}):")
        for f in fails:
            print(f"  - {f}")
        return 3
    print(f"OK cards={len(payload['cards'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
