# Same-Trial Evidence Evolution

## Goal

Reconstruct how evidence from one trial changed across selected disclosures. The objects being compared are evidence states, not competing treatments or publications.

## Step 1: Establish the common trial core

Confirm the shared trial identity, population, randomized arms, and principal study design. Note separate cohorts, extensions, substudies, and post hoc analyses instead of merging them into the core population.

## Step 2: Establish each disclosure's role

Before interpreting change over time, classify every selected disclosure on two separate axes.

### Disclosure form

Use only source-supported labels:

- **Top-line disclosure**: a preliminary headline readout or topline announcement, only when the source identifies it that way or clearly presents a topline readout.
- **Full report/publication**: a full abstract, paper, or complete result report when the format is explicit.
- **Conference/abstract disclosure**: use only when the source identifies a conference abstract, poster, oral presentation, or similar format.
- **Regulatory or sponsor update**: use only when the source explicitly identifies this format.
- **Unclear disclosure form**: use when the source does not establish the format.

### Analysis stage or scope

Use one or more source-supported labels:

- **Interim analysis**, including the stated interim number when explicitly reported, such as “first interim analysis” or “second interim analysis”.
- **Final analysis**, only when explicitly called final or when the source clearly states that the final analysis was performed.
- **Primary analysis**, when the source identifies the prespecified primary analysis.
- **Long-term follow-up/update**, when later follow-up or extended observation is explicit.
- **Subgroup analysis**, when restricted to a subgroup, cohort, biomarker group, or other subset.
- **Secondary endpoint analysis**, when the main purpose is a secondary endpoint.
- **Extension, safety, quality-of-life, or other complementary analysis**, when explicitly supported.
- **Unclear analysis stage**, when the source does not establish the stage.

Do not infer “top-line”, interim number, final status, or subgroup status from array order, publication date, database metadata, or the presence of a single endpoint. A disclosure may be both a topline disclosure and an interim analysis, or a full publication and a subgroup analysis. Keep those dimensions separate.

## Step 3: Build the evidence relationship map

Place the evidence relationship map before the detailed chronology. For each disclosure, explain its role, cutoff/follow-up, population or analysis set, and relationship to other selected disclosures. Classify relationships as duplicate, update, new endpoint, confirmation, complement, supersedes, conflict, or uncertain. State the basis for each relationship and preserve uncertainty when the supplied text cannot resolve it.

For each later evidence item relative to earlier items, use one or more labels:

- **Duplicate**: materially the same analysis and data, republished or re-presented.
- **Update**: later cutoff/follow-up or a refreshed estimate of an existing endpoint.
- **New endpoint**: adds an endpoint not previously mature or disclosed.
- **Confirmation**: independently reported later evidence supports the prior direction without merely duplicating it.
- **Complement**: adds subgroup, safety, quality-of-life, PK/PD, or methodological detail.
- **Supersedes**: a later analysis should replace an earlier estimate for the same endpoint and population.
- **Conflict**: values, populations, or interpretations disagree and cannot be reconciled from the supplied text.
- **Uncertain relationship**: the supplied text does not establish whether the evidence is new, repeated, or related.

Do not call repeated conference and journal reporting “confirmation” when both use the same cutoff and analysis.

## Step 4: Build an evidence chronology

Order disclosures using, in priority order:

1. data cutoff;
2. stated follow-up duration;
3. analysis milestone such as interim/final/planned analysis;
4. disclosure/publication date.

Database order and record update time are not clinical maturity evidence. If dates conflict or are missing, show an uncertain chronology rather than guessing.

## Step 5: Align endpoint versions

For every important endpoint, show:

- earliest disclosed state;
- later state;
- cutoff/follow-up change;
- estimate and uncertainty change;
- whether statistical status changed;
- whether the analysis population changed;
- interpretation of the change.

Do not compare subgroup medians to overall medians as temporal updates. Do not treat `NR` to a numeric median as worsening or improvement without considering event accumulation and endpoint direction.

## Step 6: Assess maturity changes

Describe maturity through concrete evidence:

- longer follow-up;
- more events;
- prespecified analysis reached;
- confidence interval narrowed or boundary crossed;
- time-to-event endpoint became estimable;
- additional safety exposure;
- durability established or weakened;
- primary findings corroborated by later endpoints;
- unresolved missing data or new inconsistency.

Avoid a generic maturity score when the concrete change is more informative.

## Step 7: State whether the trial interpretation changed

Use one of these outcomes:

- **Strengthened**: later evidence materially increases confidence or adds decision-relevant benefit.
- **Broadly unchanged**: later evidence adds detail but does not materially alter the main interpretation.
- **Qualified**: later evidence preserves part of the signal but introduces important limitations or trade-offs.
- **Weakened**: later evidence reduces confidence or contradicts an earlier favorable interpretation.
- **Indeterminate**: source gaps or conflicts prevent a defensible direction.

State exactly which new evidence caused the classification.

## Step 8: Required deep-analysis topics

- common trial identity and any cohort boundaries;
- evidence relationship map and chronology;
- duplicate versus genuinely new evidence;
- endpoint-by-endpoint changes;
- efficacy maturity;
- safety maturity;
- newly introduced limitations or conflicts;
- net change in trial interpretation.
