# Comparison Mode Detection

## Available modes

### Cross-trial comparison

Use when the selected items primarily represent different studies, trial programs, interventions, or clinical questions. The purpose is to align evidence, identify valid comparison groups, and make bounded dimension-specific judgments.

### Same-trial evidence evolution

Use when selected items are disclosures of the same underlying trial and the practical question is how evidence changed with time, follow-up, endpoints, publications, or maturity.

### Mixed or uncertain

Use when the set contains both same-trial clusters and different trials, or when source identity cannot be resolved. Partition first. Never force the entire set into one mode.

## Identity signals

Use the following evidence together:

- exact registry identifier;
- trial acronym/name;
- sponsor protocol identifier;
- intervention and control regimens;
- randomized sample size and arm structure;
- eligibility and setting;
- study geography;
- matching previously reported endpoint values;
- explicit phrases such as “previous report”, “updated analysis”, or “long-term follow-up”.

A matching registry ID is strong but still check for separate cohorts, extensions, substudies, and post hoc populations. Missing IDs require cautious matching from the remaining signals.

## Decision sequence

1. Identify likely trial identity for every item.
2. Group items that describe the same underlying trial.
3. Within each group, determine whether items cover the same cohort or distinct cohorts/substudies.
4. Classify relationships among disclosures.
5. Select the outer report mode:
   - one multi-item trial group only: same-trial evolution;
   - multiple independent trial groups: cross-trial comparison;
   - multiple groups with at least one multi-disclosure group: mixed.

## Uncertainty

If identity is probable but not confirmed, say “可能属于同一试验/项目，原文不足以确认” and show which signals match. Do not merge the records before noting the uncertainty. Carry this uncertainty qualifier through every later table, heading, and conclusion that refers to the inferred cluster; do not shorten it later to a definitive “same trial/project” statement.
