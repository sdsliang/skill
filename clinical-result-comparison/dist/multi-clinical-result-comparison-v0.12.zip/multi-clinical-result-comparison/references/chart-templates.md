# 图表模板（charts/）使用说明

> 多临床结果对比 Skill 的图表产物自 v0.12 起**统一为 JSON 文件**，遵循上游
> **chart-visualization-json** skill 的合并 JSON 协议（字段小驼峰 camelCase，
> 无额外 envelope）。本 skill 不再产出 HTML/SVG fragment：渲染由前端
> chart-visualization-json 层完成，本地只保留 `templates/charts/validate-chart.py`
> 做产物**格式合规自检**（自研轻量 JSON 结构校验，不依赖 node/zod）。

## 零、协议要点（与上游对齐，勿自造字段）

- 可渲染类型 `RENDERABLE = line | bar | timeline`；本 skill 只产出这三种。
- 顶层 meta 字段（camelCase）：`type`（必填）、`title`、`subTitle`、`dataSource`、
  `describe`、`axisXTitle`、`axisYTitle`、`theme`、`width`、`height`。
- 数据行（line/bar/timeline 的 `data[]`）一律 camelCase：`label`（维度标签）、
  `value`（**纯 number**）、`group`（多系列分组）、`description`（可选短说明，不参与绘制）。
- timeline 额外：`time`（必填，时间锚点文案；未知写「时间未明」）、`weight`（number≥0，
  驱动圆点大小）、`content`（支持 `\n` 多行）、顶层 `legend` / `weightLegend`。
- **数值纪律（硬规则）**：`value` 只放纯数字，不得把「未报告 / NR / NE / 空 /
  区间 / 95%CI / 带 % 字符串」放入 `value`——这类放该项 `description` 或正文精确数值表。
- 不写 Mermaid、不产出 `.html`。

## 一、选型规则（与 SKILL.md 工作流一致）

**先判时间维度，再判横截面：** 同一研究、同一队列、同一终点存在 ≥2 个已披露时点（长期应答维持、体重/生物标志物变化、OLE 随访、PFS/OS 按时间点）→ **优先用折线图**呈现随时间变化；单时点单值终点（ORR、EASI-75 等横截面应答率）→ 柱状图并列；证据链/里程碑顺序 → 时间轴。

| 场景 | 图表 | 模板文件 |
| --- | --- | --- |
| **同试验**证据链时间轴（≥2 个证据状态） | 时间轴（圆点坐基线 · 大小=证据成熟度） | `charts/evidence-timeline.json` |
| **同试验** OLE/长随访，同一队列多时点终点 | 折线图（同队列时点连线，无对照即单臂曲线） | `charts/endpoint-line.json` |
| **混合/不同试验**，终点无时间维（ORR 等单值） | 柱状图（横向） | `charts/endpoint-bar.json` |
| **混合/不同试验**，终点有时间维（体重、PFS/OS 按时间点） | 折线图；仅一个时间点→自动单点模式 | `charts/endpoint-line.json` |

### 时间维度优先判定（硬规则）

- **当数据集以长期随访/多时点披露为主（OLE 开放标签延展、同一队列 ≥2 个时点、停药后复发时间等）时，图表主线用折线图（`endpoint-line.json`）**，横截面单值柱状图仅作组间对照补充，不作为第一呈现。
- 折线图 `data[]` 用 `group` = 队列/治疗组、`label` = 已披露时点（W4/W12/…）。**只连线同一研究、同一队列、同一终点的时点**；不同研究/不同人群/不同队列的时点**不连线**（避免把跨研究差异误画成趋势）；不插值、不补点、不外推。
- 单时点披露（如某 OLE 只报第 68 周）用**单点模式**（前端只标点 + 数值，不强行连线），多个单点系列可同图并列。
- 无对照的开放标签单臂（婴幼儿外用药等）也按时间维度画折线，但 `subTitle`/`describe` 必须注明「单臂、无对照，仅描述随时间变化，不解读为对照获益」。
- `description` 标注时点口径（如 W16 为 OLE 基线沿用原研究基线）、分母/人群（应答者/部分应答者、n）、以及可追溯信息。

- 一个报告图数量按需组织：同试验 = 时间轴（+ OLE 多时点折线）；混合 = 时间维度优先折线 + 横截面单值柱状（每组各一图）；图多时按「时间维度 → 横截面对比」分段呈现，每张图保留解释文字与精确数值表。
- 证据边界不变：数值/披露形式/时间顺序**只能来自所选临床结果的 params 返回字段**，不得凭空编造或从记忆补；折线只连已披露时点，不外推。

## 二、怎么用

1. **复制**对应 JSON 文件为成品（不要直接改模板文件）：`cp templates/charts/endpoint-bar.json /workspace/visualizations/<slug>-endpoint-bar.json`。
2. **只改数据与文案字段**：`title`/`subTitle`/`dataSource`/`describe`/`axisXTitle`/`axisYTitle` 与 `data[]`（及 timeline 的 `legend`/`weightLegend`/`time`/`weight`/`content`）。JSON 无注释；不要加 HTML/注释/尾逗号。
3. 保存为 `<slug>.json`，正文中用 `::visualization[标题]{path="/workspace/visualizations/<slug>.json"}` **绝对路径**引用（workspace 文件 + 引用 通道），独占一行；图前后保留解释文字与 `{{ref_n}}` 标记。
   - 交付：文件**先写入** `/workspace/visualizations/`，再引用；引用路径必须从 `/workspace/visualizations/` 开头。
   - 降级：接入方不支持渲染时，正文保留文字结论 + 精确数值表 + 下载链接。

### 交付路径契约（所有图表统一遵守）

- 引用一律用**绝对路径**：`::visualization[标题]{path="/workspace/visualizations/<文件名>.json"}`。不写相对路径。
- 路径必须位于 `/workspace/visualizations/` 下；禁止目录穿越（`..`）、反斜杠 `\`、以及 `/workspace/visualizations/` 前缀之外的任何路径。
- 文件名用 ASCII 小写字母、数字、连字符（如 `train2-evidence-timeline.json`、`orr-comparison-endpoint-bar.json`），不使用子目录。
- 引用必须出现在文件写入**之后**；JSON 文件上限 1 MiB。
- 正文始终保留 fallback（文字结论 + 精确数值表），接入方不支持渲染时仍能完整理解结论。

### 数据填充约束

- timeline `data[]` 一条 = **一个证据状态**（同状态多篇披露合并为一节点），按来源支持的 数据截止→随访→分析里程碑→披露日期 排布（数组顺序即时间顺序，前端不重排）。
- **排序规则**：柱状图（`endpoint-bar.json`）如需降序由生成方按 `value` 从高到低排好 `data[]`；折线图/时间轴按**时间顺序**（`label`/`time` 数组顺序即时间顺序）。
- `value` 只填纯数字；`description` 放可追溯的补充说明（95%CI、人群口径、`{{ref_n}}` 对应信息等）。`group` 用于多系列（line 的队列/治疗组、bar 的系列、timeline 的图例 key）。
- timeline 的 `group` 必须与 `legend[].key` 一致；`weight` 0–N 表示证据成熟度/强调度。
- 引用保留：`dataSource` 行写清数据来源，正文相应位置保留 `{{ref_n}}` 标记。

### 自检（硬步骤，必跑）

**生成后自检（硬步骤，必跑）**：每个成品写入 `/workspace/visualizations/` 前，运行
`python3 templates/charts/validate-chart.py <成品文件>`，全部 **PASS** 才算完成；
**FAIL 时按输出的 JSON path 与提示修正后重跑校验，直到 PASS**，不要让非法 JSON 进入交付。
校验项：type 属于 RENDERABLE、顶层字段类型、data 非空、value 纯数字、timeline
time/weight/legend 关联、JSON 可解析、文件大小。产物是**纯 JSON**，不校验 HTML 片段（不再产出 HTML）。

## 三、配色与渲染

配色/主题由前端 chart-visualization-json 渲染层统一处理（本 skill 不产出自带 CSS/HTML 的图表）。
如需指定主题可填顶层 `theme: "default" | "academy" | "dark"`（可选，默认 default）；不填亦可。
本 skill 不在 JSON 内混入自定义色板或 HTML token——视觉统一由渲染层保证。

## 四、与 chart-visualization-json 的关系

- 本 skill 产出的是**合并 JSON**：顶层 meta（title/subTitle/dataSource/describe/axisXTitle/
  axisYTitle 等）+ `type` + `data[]`，与上游 `chart-visualization-json` 的 `splitChartConfig`
  （meta/payload 分层）和 28 类型校验对齐；本 skill 只用开放渲染的 line/bar/timeline 三类。
- 更花哨的图型/复杂编排属上游 skill 能力，本 skill 不越界产出不可渲染类型。
- 本地 `validate-chart.py` 是对照该协议的自研轻量校验（Python，无 node/zod 依赖），
  用于交付前格式自检；不替代上游渲染层的最终校验。

## 五、当前版本边界

- 全部图表（同试验时间轴、混合/不同试验柱状与折线）统一走 **JSON 文件 + `::visualization` 引用**，随 v0.12 生效（v0.11 及以前为 HTML fragment，已归档 `docs/legacy-html-charts/`）。
- 不再输出 Mermaid、不再输出 `.html` 图表文件。
- 证据边界不变：数值/披露形式/时间顺序只能来自所选临床结果 params 字段。
