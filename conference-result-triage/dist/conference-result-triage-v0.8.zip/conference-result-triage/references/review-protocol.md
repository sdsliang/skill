# 复核协议（模型逐条判读）

这一步是 skill 的价值所在：**机器能筛出 467 条，只有人能说清哪 30 条值得看。**

## 1. 批次设计（决定性约束）

| 参数 | 值 | 原因 |
|---|---|---|
| 每批条数 | **15** | 单条压缩摘要约 2.5 KB（Results 不再截断）+ 元数据，15 条约 37 KB，**低于工具单文件读取上限（~50 KB）** |
| 分片粒度 | 每片 15 条，独立 JSON 文件 | 一片一文件，避免一次读 300 KB 的行 |
| 索引方式 | **显式顺序 `i`（1..N）** | 不要用 esid 直接下标；池内顺序与批次顺序不一定一致，之前用 esid 索引导致整批错位 |

分片文件结构：

```json
{"items": [{
  "i": 1,
  "bucket": "early",
  "abstract_id": "5RO",
  "presentation": "Rapid Oral",
  "trial": "ABBV-706 ph1",
  "indication": ["小细胞肺癌"],
  "phase": "Phase I",
  "evaluation": "积极",
  "n": 124,
  "randomized": "否",
  "trial_control": null,
  "key_evidence": "是",
  "primary_endpoint": ["ORR"],
  "refractory": ["TOP1i-ADC 耐药", "既往 ≥2 线"],
  "table_only": false,
  "condensed": "#### Background ... #### Results ... #### Conclusion ...",
  "summary": "..."
}]}
```

`condensed` 的压缩比例：

- Background：前 320 字符（够拿到药名 + 靶点 + 设计）
- **Results：全文，不截断**（这是 v0.2 最重要的一条）
- Conclusion：前 280 字符
- `summary`（`clinical_result_summary`）作为**独立字段**并列给出，不要拼进 `condensed`

### 1.1 为什么 Results 不能截断

v0.1 把 Results 截到 760 字符，实测代价：

- ESMO 2026 摘要 Results 段中位数 **956 字符**，最长 2094 —— **52%（338/646）的摘要把关键数字印在 760 之后**；
- 低分条目里有 260 条 Results > 760，其中 **117 条（45%）在截断点之后还有带百分比的疗效数字**，只有 4 条是真的「数字只在未展示的表里」；
- 直接导致两名内部专家推荐被误判为 weak：HS-20122 的 `52.5%` 在 Results 偏移 919，CM518D1 的 `33.3%` 在偏移 851。

整篇摘要才 ~2 KB，截断没有收益，只有损失。**宁可多读，不要丢数字。**

## 2. 每条必须输出八个键（含判读评分）

```json
{
  "i": 17,
  "bucket": "pivotal",
  "verdict": "keep",
  "score": 78,
  "score_parts": {
    "evidence_strength": 26,
    "effect_size": 22,
    "clinical_impact": 20,
    "novelty": 4,
    "readout_maturity": 6
  },
  "reason": "随机对照 PFS 16.1 vs 6.9 月，HR 0.56",
  "evidence": "PFS was significantly improved with pembro-CT vs pembro (16.1 vs 6.9 months; HR 0.56)",
  "key_numbers": ["PFS 16.1 vs 6.9 mo", "HR 0.56", "OS 50.2 vs 29.9 mo"]
}
```

| 键 | 约束 |
|---|---|
| `i` | **原样抄**，一个字都不能改；改了就无法回填 |
| `bucket` | 按证据强度重判（见 §3），可以覆盖机器分桶 |
| `verdict` | 只能 `keep` / `weak` / `drop` |
| `reason` | ≤40 字，中文，写"为什么"，不写"是什么"；人群难度档必须写进去 |
| `evidence` | **逐字**从该条 `condensed` 摘 1 句，≤120 字符，不改写、不拼接、不翻译 |
| `key_numbers` | 该条摘要里出现过的具体数字，不重算 |
| `score` | **你判读出来的** 0–100，不是脚本算的、不是按公式套的 |
| `score_parts` | 五个维度各自的分值，加起来必须等于 `score` |

## 2.5 判读评分卡（你打分，脚本不参与）

**为什么不是脚本打分。** 试过：用 `phase` + `randomized` + `n` + 正则抓 HR/p 做加权，结果把安全性摘要排到了疗效摘要前面——`PR count = 3 subjects` 被当成缓解率，而占多数的 `study_results` 行根本不含 p/HR。规则算出的分是**假精确**。所以分必须由读过摘要的人给，脚本只负责检查这个分自洽。

五个维度，**权重是上限**，给多少你自己判：

| 维度 | 上限 | 判什么 | 给高分的典型情形 |
|---|---|---|---|
| `evidence_strength` | 30 | 这个证据本身有多硬 | 随机对照、双盲、样本足、主要终点预设、随访成熟；单臂小样本、剂量爬坡、事后亚组给低分 |
| `effect_size` | 25 | 效应有多大 | HR 明显低于 1、OS 绝对获益显著、ORR 远超该人群历史水位、阴性结论明确到没有争议（失败桶照样给高分） |
| `clinical_impact` | 25 | 会不会改变实践 / 填补什么空白 | 新标准治疗可能、首个针对某耐药人群的有效方案、推翻现行用法（失败桶：改变了多少人的用药预期） |
| `novelty` | 10 | 机制/靶点/资产有多新 | 首创机制、首次人体、首次在该适应症读数；me-too 跟进扣分 |
| `readout_maturity` | 10 | 数据熟不熟 | 成熟随访的 III 期；首次公布但只有早期随访给中低分；同一数据的又一次 cut **不应因为"更新"就加分** |

打分纪律：

- **分数要能落到摘要里的字**。给 `effect_size` 22 分，`reason` 或 `evidence` 里就得有支撑它的数字；拿不出数字的维度给 0，不要给"看起来还行"的分。
- **不要为了排序好看调分**。同一个数字在不同桶里该得的分不一样（失败桶里 HR 1.48 是"明确阴性"= 高分，疗效桶里 HR 1.48 是"无效"= 低分），按维度含义给，不要横向比。
- **`weak` 也可以有分**（比如 42 分）——`verdict` 说的是"凭这篇摘要敢不敢下结论"，`score` 说的是"这条证据本身有多重"，两者不冲突。
- 五维相加必须等于 `score`；上限是硬顶，超了脚本会拒。
- 分数**不写进给读者看的 `why`**（读者看的是理由，不是分数），但清单里保留，方便你知道编辑排序的边界在哪。

## 3. 分桶重判（按证据强度，不按期别数字）

```
if 主要终点未达 / 未显著 / 无效 / 提前终止（did not meet, no significant,
   terminated, HR 跨 1, p 不显著）:            → failed   （失败优先）
elif 随机对照 + 主要终点达成 + 有临床意义:      → pivotal
elif 单臂 / 无对照 / 剂量爬坡 + 有具体疗效数字:  → early
else: 保留机器分桶
```

实测会被这条规则改判的例子：III 期但 OS 未达的 postMONARCH（pivotal → failed）、Phase II 但有随机对照的 COMPANION-002（机器 pivotal，保持）。

## 4. verdict 的判定标准

| verdict | 条件 |
|---|---|
| `keep` | 数字明确：ORR ≥ 40%（后线/耐药 ≥ 25%）/ HR ≤ 0.75 / OS 绝对获益 ≥ 3 月 / 明确阴性结论；且能引出具体数字 |
| `weak` | 有疗效数字但样本 < 20、单臂极小样本、关键数字落在未给出的 table 里；或 ORR 在一般人群 25–40% 且无其它支撑 |
| `drop` | 只有安全性 / PK / 生物标志物 / HRQoL；或只说"将继续评估"而无结果 |

注意：

- **ORR 门槛按人群难度分档，不是一把尺**：一线/未治疗 ≥40%，后线（≥2 线）或明确耐药人群 ≥25%。降档的**前提是 `reason` 里写明人群**（几线、既往用过什么），只降门槛不写人群 = 放宽标准。
- **“数字明确”不等于“值得推荐”**。keep 只是"可以进入定榜候选"，定榜还要看适应症难度、机制新颖度、是否首次公布、**报告形式**。
- `weak` 不是"差"，是"凭这篇摘要判不了"。
- 明确阴性（如 ORR 0%、OS HR 1.48）也是 keep —— 失败桶要的就是这种。
- **口头报告不等于数据更好**，但口头报告 + 强数字是双重信号；只有口头没数字不能 keep。

## 5. 合并与校验（必做，不做就会静默错位）

合并全部批次后：

1. **条数校验**：判定条数 == 池子条数（ESMO 2026 v0.2：532）。
2. **i 覆盖校验**：`set(i) == set(range(1, N+1))`，缺一个就重跑对应批次。
3. **evidence 逐字校验**：把 `evidence` 与 `condensed` 都做空白归一 + 小写后做子串匹配。
   - 命中率参考：ESMO 2026 首轮 400/467 = 86%；v0.2（532 条 / 36 批）**532/532 = 100%**，`reason` 超 40 字的 0 条。
   - 首轮命中率低于 95%  практически всегда 是分片时 `condensed` 与判定时读到的不一致（截断、字段名写错、改用了 `summary`），先查这个再查模型。
   - **未命中的 evidence 不得进入交付物**，改用机器信号或标「待核实」。未命中通常来自表格排版被转写、跨行拼接。
4. **评分自洽校验**：`score` 是 0–100 整数；`score_parts` 恰好五个键、各不超上限、**相加等于 `score`**。不相等说明分是凑出来的，退款重判该条（不要手工改分——改了就没法追溯是判读还是编辑定的）。
5. **bucket 合法性校验**：`bucket` 只接受 `early|pivotal|failed`；出现 `keep|weak|drop` 说明模型把 verdict 写进了 bucket，回退到机器分桶。

## 6. 任务拆分与模型选择

- 532 条 / 15 = 36 片 → 分 6–7 个子任务，每个 5–6 片。
- 首选稳定可用的模型；实测 `gpt-5.6-terra` 在 6/6 子任务上稳定，grok 系列易 idle timeout，部分 key 对 5.5/5.4 返回 403。
- 子任务提示词必须自带全部规则（不要让它去读 SKILL.md，子任务上下文很贵）。
- **分片文件里必须自带正文**。ESMO 2026 首轮踩过：池子条目只有 `abstract_text`，`condensed` 字段是复核批次阶段才拼出来的；直接拿 pool.json 切片 → 6/6 子任务收到 `condensed = null` → 4 个子任务拒绝判定、2 个改用 `summary` 凑数（keep 率从 24% 掉到 3%）。**切片要基于 `review.jsonl` 的 batch item**（含 `background` / `results` / `summary`），落盘前断言 `all(it['condensed'] for it in items)`。
- **单文件体积 ≤ 40 KB**。36 片实测 max 40,804 B / avg 35,964 B —— 再大就顶到 `read` 的 50 KB 上限。

## 7. 定榜（三步收敛：keep → 初选 15 → 联网终选 10）

| 阶段 | 上限 | 输入 | 产物 | 是不是交付物 |
|---|---|---|---|---|
| keep | 无（全量判读） | 全部候选 | `judged_*.json` | 否 |
| 初选 | **每桶 15 / 全场 45** | keep | `work/shortlist.json` | 否 |
| 终选 | **每桶 10 / 全场 30** | 初选 + 联网检索 | `work/plan.json` | 是 |

**为什么要两道收敛**：15 是机器短名单的硬上限（防止池子变成倾倒场），10 是**阅读**上限——一份 15 条的清单读者不会看完，一份 10 条的会。两段的边界不一样：初选按判读分，终选让外部世界参与。

不足就写不足，两段都不许用 `weak` 凑数。

### 7A 初选：keep → ≤15

按顺序：

1. **压同质**：同一病种同一机制最多留 2 条（ESMO 2026 早期桶里 SCLC 的 DLL3/SEZ6/B7-H3 ADC 有 5 条 keep，只留最强的 3 条）。
2. **标注数据类型**：首次公布 > 更新 > 亚组/二次分析。更新类进榜的**理由必须是"数据更成熟后结论更硬"**，不能写成"新药"。
3. **标出报告形式**：每条写「口头 / 快速口头 / 壁报 / 电子壁报」。同分时口头优先。
4. **补全药物信息**：`trial_abbreviation` 常看不出药名（如 `PERSEE`、`CA017-078`），必须从摘要 Background 段取药名 + 靶点；会议库已直接给出 `drug` / `target` / `moa` 字段，优先用它。
5. **跑同资产历史对照**：`scripts/history_for.py --pool pool.json` 拉每个药历次会议的数据，进榜条目必须看一遍。ESMO 2026 实证：SYS6043 从 ASCO 2026 到 ESMO 2026 从 64.0% 降到 45.7%（样本 502 → 137），9MW2821 从 ESMO 2023 的 38.5% 一路降到 30.0% —— 这种趋势单次会议快照看不出来。
6. **写候补**：每桶列 2–4 条"差一位"，方便读者知道边界在哪。
7. **不足就写不足**，不要用 weak 凑数；超了按 `score` 从高到低取，同分看报告形式。
8. **排序以判读 `score` 为主序**，编辑判断可覆盖，但覆盖要在 `why` 里说清楚为什么不按分排（例：两条同机制，分高的那条已被更早的会议读过）。

**定榜排序不能只靠机器 sort。** 池子按 `(presentation_rank, -n)` 排，那是**为了决定先读谁**，不是推荐次序；真正的次序来自 §2.5 的判读分 + 你的编辑判断。ESMO 2026 实测：7 条专家选择在机器序里排名为 2 / 19 / 27 / 72 / 101（另有 2 条判 weak 未入 keep），两条壁报 `1029P`、`2567P` 因 n 小被压到 72 和 101 名 —— 壁报档里 n 大的平庸研究一定压过 n 小的耐药人群研究。所以定榜由人（或复核模型读完全部 keep 后）排序，脚本只负责按给定顺序渲染（`scripts/make_watchlist.py` 就是只渲染、不排序）。

**定榜要交付三件**：`judgements.csv`（全量判定，机器桶与复核桶并排）· `watchlist.csv` / `watchlist.md`（定榜）· `history.md`（同资产历次读数）。

### 7B 联网终选：≤15 → ≤10（v0.7）

这一步的判据有一半来自会议库之外，所以**必须由主 agent 亲自执行检索**，不能丢给 `task` 子代理——子代理只回结论，你拿不到 URL 标题，就无法判断那条"热议"是会议现场的报道还是聚合站的自动摘要。

**工具与开关**：检索工具是平台的 `web_search`（有的模型把它渲染成 `web.run`；入参 `query`/`queries`，返回 `sources` + `items[url,title]`）。**双重开关**：项目能力 `web=true` **且** 回合以 `enable_web=true` 发起（UI 的"联网"按钮）。实测过"能力开了、回合没带 flag"的情形：模型看到的工具表里干脆没有检索工具，然后它开始按常识编。**工具不在工具表里就停下、让用户开联网**，不许假装查过。

**每桶至少 6 次查询**，四类各覆盖：

| 目的 | 查询模板 | 判据 |
|---|---|---|
| 会议现场热度 | `"<会议> <药名/试验名> results"` | 多家专业媒体单独成文 = 热点 |
| 适应症内定位 | `"<药名> <适应症> data <会议> <年份>"` | 是否被写成"该适应症本届最受关注" |
| 股价/公司 | `"<ticker> 收盘 <YYYY年M月D日> 涨跌幅"` | 必须能对上 `prev_close→close`，口径见下 |
| 未被收录的热点 | `"<会议> late-breaking abstract <适应症> most anticipated"` | 用来发现机制上被漏掉的研究 |

**证据落 `work/web/<bucket>.jsonl`**，一行一次检索：`{"query","title","url","published_at","note"}`。平台 `/workspace/tool_results/` 回合结束即清空，只有这个文件能让复核者回到原始来源。

**两种用法**：

1. **纠偏（promote）**：外部热议、但初选漏了的研究可以提上来，**前提是它在 `work/rows.json` 里** —— 卡片上的每个数字都必须在那条记录自己的原文里出现。写卡时标 `"promoted": "web"`，并在 `why` 里写明外部讨论的是什么。会议库根本没有这条记录时**不能进卡**，只能写进 `coverage_notes`（"外部讨论了 X，会议库无对应记录，未纳入"）。`check_cards.py --rows` 会反查。
2. **上市公司（`listed_company`）**：每张卡都要这个键。上市 ⇒ `{name, ticker, exchange, reaction, source_url}`，`source_url` 必须是真打开过的 IR/交易所/行情页；未上市或查不到 ⇒ `null`。**不要用同名母公司顶替**（一个管线属于子公司，股价反应落在母公司 ticker 上时要在 `name` 里写清这一层）。**`reaction` 是对象，不是短句**（v0.8）：`{from_date, to_date, prev_close, close, change_pct, basis, source_url}`。取数两条正路 —— ①`web_fetch` 东财 kline JSON：`https://push2his.eastmoney.com/api/qt/stock/kline/get?secid=<mkt>.<code>&fields1=f1,f2&fields2=f51,f53&klt=101&fqt=1&beg=YYYYMMDD&end=YYYYMMDD`（前缀 NASDAQ 105 / NYSE 106 / AMEX 107 / HKEX 116 补零 5 位 / LSE 155；`rc:102` = 市场不覆盖，SIX 就在这一类）；②`web_search` 查 `"<ticker> 收盘 <日期> 涨跌幅"`，deepseek 源直接返回券商页的收盘与涨跌幅。口径固定为「**该市场**早于会议首日的最后收盘 → **该市场** ∈ 会议窗口的第一个收盘」，`basis` 必须写明"非归因"；基准日按市场各自取（港股 2026-10-19 台风停市，只能用 10-16 → 10-20）。取数结果逐行落 `work/web/quotes.jsonl`，交付时 `check_cards.py --quotes-evidence`。没核实到就**省掉 `reaction`**（合法），**不许拿 OTC ADR 顶替本土上市股**（`RHHBY` ≠ `ROG.SW`）。

**联网层失败只降级、不中止**：检索无返回、IR/交易所页 403 或超时，都不允许拿"查不到"当理由不出清单。顺序是：换词换源再试（检索结果里的标题和 URL 已经够填 `listed_company.source_url`，不必打开页面）→ 仍不行就按判读分收敛到 10 条、`listed_company` 全填 `null` → 在 `coverage_notes` 写「联网核实未完成（原因）」→ 照常交付。`cards-e2e5` 就是这么废掉的：`web_search` 明明返回了 12 条来源，`web_fetch` 打开 amgen.com 失败后模型写"搜索无可用返回"，结束回合、零交付。

**终选判据**：判读分仍是主序，外部信号可以覆盖，但覆盖必须写进 `why`（"多家报道把它列为本届该适应症最受关注的口头报告，分数把它排在 12 位"）。同机制仍最多 2 条。**宁缺不凑**：8 条诚实的清单好过 10 条注水的。

## 8. 平台内执行（v0.3）：子任务委派契约

候选超过 40 条时，主线程不逐批读，改派 `task`。子代理**不继承本 Skill 的 prompt 与 references**，所以每个 `task` 的 description 必须自带完整契约：

```
1. 读 /workspace/work/pool/review_<n>.json（含 items 数组）
2. 逐条判读全部 items，不得跳过
3. 每条输出 {i, bucket, verdict, score, score_parts, reason, evidence, key_numbers}
   - score 是你判读出来的 0–100 整数；score_parts 五维
     {evidence_strength≤30, effect_size≤25, clinical_impact≤25,
      novelty≤10, readout_maturity≤10}，五维相加必须等于 score
   - 分数要能落到摘要里的字：撑不起某维度就给 0，不要给"看起来还行"的分
   - 失败桶的"明确阴性"照样高分（effect_size / clinical_impact 高）
   - i 原样抄，不改动，不用 esid 索引
   - bucket ∈ early|pivotal|failed，按证据强度重判；lba=true 不自动升 pivotal
   - verdict ∈ keep|weak|drop（阈值见下）
   - reason ≤40 个汉字，必须点出人群难度档
   - evidence 必须是该条 results 或 background 的**连续原文子串**（≤120 字符）：
     不拼接两个分离句子、不改写、不去表格 `|`、不翻译
   - key_numbers 只列带单位数字（%、月、HR、OR/CI、p），不列纯计数/年龄
4. 写 JSON 数组到 /workspace/work/judged_<n>.json（UTF-8，不留占位）
5. 读回该文件确认是合法数组且条数等于输入条数，回复一行 OK <条数>
```

一次性把 2–3 个批文件分给一个子任务；**所有 `task` 调用放在同一条消息里**（分开发会串行执行）。文件体积上限按 40 KB 控制，超过就再切——工具的读取上限会让子代理只看到半截，而它不会报错。

合并前主线程必须跑机械校验（条数 / `i` 覆盖 / `evidence` 子串 / `reason` 长度 / 评分五维求和）。**校验不过整批重跑，不许手工修补**：一个"看起来合理"的 evidence 是不可核验的。

## 9. verdict 阈值（子任务里要重述，不能只写"按协议"）

| 人群 | ORR 门槛 |
|---|---|
| 一线 / 初治，非耐药 | ≥ 40% |
| 后线（≥2 线）或明确耐药 | ≥ 25% |

降档**必须把人群写进 reason 或 evidence**（几线、既往失败过什么）。9MW2821 在 TOP1i-ADC 耐药 TNBC 的 ORR 30.0% / mPFS 3.7 mo 就是这条规则的来源。

其它 keep 条件：HR ≤ 0.75、OS 绝对获益 ≥ 3 月、明确阴性结论。
`weak`：有数字但 n<20、单臂极小、关键数字只在未给出的表里、一般人群 ORR 25–40% 且无其它支撑。
`drop`：只有安全性 / PK / 生物标志物 / HRQoL，或只说"将继续评估"。
