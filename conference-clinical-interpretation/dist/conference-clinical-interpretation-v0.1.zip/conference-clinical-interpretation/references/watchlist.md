# 推荐关注清单 (Watchlist)

推荐关注清单是「会议临床解读」的第二交付物：从会议全部记录中筛出**临床价值最高**的试验，独立成 `watchlist.csv`，并在报告第 8 章以表格呈现。

## 1. 原则：热度 ≠ 记录数

清单排序**不按记录数**，按综合临床价值评分（0-100）。数量多只说明曝光广，不代表值得关注。

## 2. 评分维度与权重

| 维度 | 权重 | 说明 |
|---|---|---|
| 试验阶段 | 25% | III 期最高（注册级），II 期中高，I 期最低 |
| 评价 | 25% | 积极 > 其他；不佳/终止不是 0 分但需标注警示 |
| 样本量 | 20% | 样本量大者证据更稳（缺失记中位分） |
| 终点证据强度 | 15% | OS 证据 > PFS/ORR 等中间终点；`efficacy_text` 含数值为佳 |
| 机制/适应症新颖度 | 15% | 新机制、冷门高需适应症、标志物导向加分 |

评分在报告中说明方法，不要求精确到小数——给整数分与理由即可。

## 3. 清单条目字段（CSV 列）

```csv
rank,evidence_id,title,trial,indication,drug,phase,sample_size,evaluation,score,reason
```

- `rank`：1..N，按 score 降序，N 建议 10-20。
- `evidence_id`：`evidence_scatter[].id`，保证可溯源。
- `title`：论文标题。
- `trial`：试验缩写或 NCT。
- `indication`：主要适应症（首个）。
- `drug`：主要药物（首个，优先免疫/靶向/新药，非化疗辅药）。
- `phase`：研发阶段。
- `sample_size`：样本量（整数，缺失留空）。
- `evaluation`：积极/不佳/终止。
- `score`：整数评分。
- `reason`：一句话理由，含"热度≠记录数"的价值判断。

## 4. 生成步骤

1. 从 `evidence_scatter` 按评价 = 积极 + 阶段优先（III 期 > II 期）粗筛候选。
2. 综合评分维度排序，取 Top 10-20。
3. 写入 `/workspace/visualizations/watchlist.csv`（UTF-8，含表头）。
4. 报告第 8 章以 Markdown 表格呈现同数据，并用 `::visualization[推荐关注清单]{path="/workspace/visualizations/watchlist.csv"}` 引用 CSV 供下载。

## 5. 平衡与警示

- 若某领域积极证据少但临床需求大，可在清单旁标注"证据尚弱但方向值得关注"。
- 不佳/终止的高关注试验不进入主清单，但在报告第 7 章警示；若其价值在于负面教训，可在清单末附加 `rank=z1,z2...` 标注。
- 不因记录数高而自动入选；不因记录数低而自动排除。
