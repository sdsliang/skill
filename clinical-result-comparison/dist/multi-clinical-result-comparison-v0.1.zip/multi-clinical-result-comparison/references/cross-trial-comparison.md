# Cross-Trial Comparison

## Goal

Answer which selected result is stronger, weaker, or simply different without turning heterogeneous studies into a false league table.

## Step 1: Form clinical-question clusters

Cluster records using the clinical question, not disease name alone. Consider:

- intended condition or symptom;
- population and treatment setting;
- therapeutic objective;
- intervention role;
- outcome domain.

Examples within one disease may still require separate clusters for survival, symptom control, physical development, body composition, and long-term metabolic safety.

If two results answer different clinical questions, compare their evidence scope and relevance but do not declare one treatment clinically superior. Do not create a shared “efficacy winner” across clusters based on positivity, p-values, endpoint hierarchy, or narrative strength; those quantities answer different questions.

## Step 2: Align fields

For every cluster, align:

- population;
- intervention and regimen;
- control;
- design;
- sample and analysis set;
- endpoint hierarchy;
- endpoint definition;
- statistic and direction;
- time point/follow-up;
- efficacy and safety completeness.

Use `未报告` when absent. Do not replace a missing value with an inference.

## Step 3: Classify endpoint alignment

Assign one level for each attempted endpoint comparison:

- **Directly aligned**: same clinical construct, materially compatible definition, population, statistic, and time frame.
- **Partially aligned**: same construct but one or more meaningful differences require caution.
- **Context only**: related domain but different endpoint definition, statistic, population, or timing prevents numeric comparison.
- **Not aligned**: different clinical question or no counterpart.

- **Directly aligned** and **Partially aligned** endpoints may support a bounded comparative direction after considering design and uncertainty.
- **Context only** and **Not aligned** endpoints must not produce a leader, directional winner, or raw-number ranking. Report the values only inside their own source contexts.

## Step 4: Judge comparison confidence

Assess the comparison as a whole using observable properties rather than a fixed score:

- similarity of patient populations;
- compatibility of interventions and controls;
- study-design differences;
- endpoint alignment;
- timing/follow-up alignment;
- analysis maturity and statistical completeness;
- safety exposure and reporting completeness.

Use one label:

- **High comparability**: rare outside a head-to-head or closely matched design; supports a strong comparative statement.
- **Moderate comparability**: supports a cautious directional comparison.
- **Low comparability**: supports context-level observations only.
- **Not meaningfully comparable**: do not rank outcomes.

Cross-trial comparisons usually cannot establish treatment superiority even when comparability is moderate or high. State that distinction clearly.

## Step 5: Make dimension-specific judgments

For each sufficiently aligned dimension **within the same clinical-question cluster**, use one of the labels below. “Favored” and “directionally favored” are available only when endpoint alignment is Directly aligned or Partially aligned:

- **Result A is favored on this dimension**: the evidence supports a clear within-scope advantage.
- **Result A is directionally favored**: the observed signal points toward A, but indirectness or uncertainty prevents a firm claim.
- **No material difference demonstrated**: the supplied evidence does not establish a meaningful difference.
- **Cannot determine**: missing or incompatible evidence blocks judgment.

Always attach the reason and confidence. Do not rank a raw percentage or median without verifying endpoint direction and context.

## Step 6: Decide whether an overall winner exists

An overall winner requires all of the following:

- the compared results address substantially the same clinical question;
- key populations and regimens are sufficiently compatible;
- at least one decision-relevant efficacy endpoint is directly or partially aligned;
- safety evidence is not missing in a way that could reverse the decision;
- findings are directionally coherent across the most important dimensions;
- the wording does not imply head-to-head proof when none exists.

If any condition fails, report no overall winner and provide the most decision-relevant dimension-specific conclusion instead. When the input contains multiple clinical-question clusters, report leaders only inside each cluster and use `不适用` for any cross-cluster efficacy winner.

## Required deep-analysis topics

- what can be compared and why;
- what cannot be compared and why;
- efficacy signal and its maturity;
- safety signal and reporting completeness;
- study-design impact on confidence;
- source rhetoric versus supported conclusion;
- dimension-specific leader, if any;
- whether an overall winner is justified.
