# 证据链时间轴图（JSON 可视化）

## 适用范围

- 仅用于**同一试验的多篇披露**（合并后 ≥2 个真正不同的证据状态）的输入。
- 不用于跨试验或混合输入：不同试验没有共享时间线，不生成该图。
- 交付方式：**用 `python3 /workspace/skills/multi-clinical-result-comparison/scripts/make_chart.py` 组装**——把下面示例当作**内容 spec**（`type` + `file` + `language` + 文案 + `data[]`）保存为 `work/charts/evidence-timeline.json`，脚本从**运行期**图表 skill 取 envelope 四键（`id`/`version`/`iframe_template`/`config`，`version` 与 `iframe_template` 每次发布都变、禁止硬编码）、从本 skill `templates/charts/evidence-timeline.json` 取 `config` 骨架、把 `describe`/`dataSource` 渲染成 `config.notes`，写入 `/workspace/visualizations/evidence-timeline.json` 并跑上游校验。**不要**自己 `cp` 上游模板、**不要**手拼 envelope。正文“证据链总览与时间线”一节中在时间线表格上方用 `::visualization[标题]{path="/workspace/visualizations/evidence-timeline.json"}` 绝对路径独占一行引用（写入 `/workspace/visualizations/` 后再引用；禁止目录穿越/反斜杠/前缀外路径，文件名 ASCII）。**不再输出 Mermaid 代码块、不再产出 HTML 图表。** 接入方不支持可视化文件时，正文保留时间线表格 + 文字结论，并提供图的下载链接。

## 图要回答的问题

一张图同时展示四件事：

1. **时间顺序**：证据状态按来源支持的时序**自上而下**排列。排序优先级为 数据截止 → 明确随访 → 分析里程碑 → 披露日期；绝不使用输入顺序、数据库顺序或运行时间戳。时间轴 `data[]` 数组顺序即时间顺序（前端不重排）。
2. **每个状态新增了什么**：节点 `content`/`description` 用**定性短语**写明本状态新增了哪类信息（终点、亚组、安全性、随访成熟度、方法），**不写数值**。
3. **相邻状态的关系**：用节点 `description` 或正文文字写明"更新 / 新增终点 / 确认 / 补充 / 取代 / 冲突 / 不确定"。
4. **证据链的判断怎么变**：整体判断是加强、基本不变、受到限定、削弱还是无法确定，**写在正文与节点 `description` 的文字里**，并说明由哪些证据状态引起——**不用节点大小、形状、颜色或图例编码**（现行时间轴渲染为竖向列表，每个节点等大等形且不渲染图例，`weight`/`weightLegend`/`legend` 都没有任何视觉效果，见构建规则第 8 条）。

## 图表职责分工（硬性：图只画骨架，表是数值唯一出处）

同一交付里，图与时间线表格**不得重复表述**：

- **数据截止/随访时长、样本量、发生率、HR/CI/p、终点数值、统计量 —— 只出现在时间线表格**（以及正文中真正支撑结论的句子里）。图中出现数字的唯一位置是 `time` 的时间锚点本身（年月/日期），其余一律禁止。
- **图只承担表格做不到的事**：时序排布、状态之间的关系、以及节点文字里写明的「本状态新增了什么」。图的价值在于“一眼看出链条怎么长起来的”，不在于复述表格。
- 违反后果：用户反馈“图只是把表格又画了一遍，占版面又没信息”。R37 实测：图 `content`/`description` 逐字复述了表格的「数据截止/随访」「主要披露内容」「与前序关系」三列。

## 构建规则

1. **一个证据状态对应一个节点**，不是一篇披露；可另加来源支持的研究里程碑（在 `label` 文字里点明，如「研究启动（里程碑）」），但里程碑不计入证据状态数或 ≥2 状态出图门槛。合并为同一状态的来源共享一个节点：`label` 写状态名 + 分析阶段/披露形式（如"pCR 主要分析 · 摘要/主刊"），`description` 中并列列出该状态支持来源的引用标记（如 `{{ref_1}}{{ref_3}}`）；披露数量多不代表独立验证。
2. **节点内容字段**（camelCase，与上游 chart-component-layout-json-validation 协议一致）：
   - `label`：证据状态名 + 分析阶段/披露形式（**≤18 字**，string，必填）；
   - `time`：本状态来源支持的时间锚点文案（**只写年月/日期，如 `2020-05`**；缺失写「时间未明」），不得猜测或推算日期，也不要把表格里的随访时长/样本量搬进来（string，必填）；
   - `group`：上游协议保留的可选字段，但现行时间轴**不渲染图例、也不按组区分形状/颜色**，本 skill 不用它表达任何含义（可省略）；
   - `content`：本状态**新增了哪类信息**的定性短语，**≤16 字**，支持 `\n` 多行（string，可选）；⛔ **不得含数字、百分号、单位、HR/CI/p 或日期（时间已由 `time` 承担）**；
   - `description`：只写「与前状态的关系 + 成熟度方向 + 引用标记」的短句，如 `主要终点首次达标；疗效判断成立{{ref_1}}`（string，可选）；⛔ 不复述表格数值、截止日期、样本量或整句结论。
3. **时间轴**：节点按时间先后在 `data[]` 内排好（数据截止 → 明确随访 → 分析里程碑 → 披露日期），渲染端自上而下逐条渲染、不重排。某状态没有来源支持的时间时，`time` 写「时间未明」。
4. **边关系与成熟度**：相邻状态的关系（更新/新增终点/确认/补充/取代/冲突/不确定）写在图下方正文或节点 `description` 中，格式为"关系 + 成熟度方向"，例如 `新增终点 + 更长随访，疗效判断加强（OS 仍属中期）`。只有原文支持才标注关系；无法确定的写"不确定"。
5. **成熟度边界**：只写来源支持的成熟度判断。首次/中期分析必须保留"首次/中期"字样，不得写成最终分析。
6. **标签安全**：`content`/`description` 不得出现来源数值（图只承担时序与状态关系，数值留在表格）。`value` 语义在本图不使用；不得插值、合并、排名或按披露数量制造时间点，也不得为凑节点编造定性描述。
7. **回退规则**：
   - 合并后只有 1 个证据状态（其余都是纯重复），或任意两个状态的先后都无法由来源确定时，**不生成时间轴图**，仅保留时间线表格并明确说明顺序不确定。
   - 时间轴图是描述性示意图，不能替代表格中的精确数值；时间线表格必须始终保留。
8. **禁止 `weight` / `weightLegend` / `legend`（硬性）**：现行时间轴渲染是**竖向列表**（每个节点 = 时间 + 卡片），**所有节点等大等形、不渲染图例**，`group`/`shape` 在画布上也不生效。因此 `weight`（大小）、`weightLegend`（权重图例）、`legend`（分类图例/形状）都不会产生任何视觉差异——写了只会给出“成熟度或分类已被编码”的错觉，读者无从解码。证据成熟度一律用文字表达：正文写整体判断，节点 `description` 写“关系 + 成熟度方向”；分类（里程碑/披露/更新）写在 `label`/`content` 的文字里。`scripts/make_chart.py` 据此拒收带这些字段的 spec，`scripts/check_report.py` 据此拒收带这些字段的成品与相关文字表述。

## 数据填写示例（TRAIN-2：5 篇披露合并为 3 个证据状态）

来源 `{{ref_1}}` 与 `{{ref_3}}` 共享同一 pCR 主分析（同一 418 例可评估与数值），合并为一个 pCR 状态；来源 `{{ref_2}}` 与 `{{ref_4}}` 共享同一 3 年随访分析（同一 438 例、48.8 个月随访与数值），合并为一个 3 年随访状态。图中不产生五个独立节点，也不把重复披露解释为独立验证。

注意示例中**图内没有任何数值**：样本量、pCR/EFS/OS 数值、p 值与随访时长全部留在时间线表格里，图的 `content` 只是「本状态新增了哪类信息」的定性短语，`description` 只写关系 + 成熟度方向 + 引用标记。

```json
{
  "type": "timeline",
  "file": "evidence-timeline.json",
  "language": "zh",
  "title": "TRAIN-2（NCT01996267）证据链时间轴",
  "subTitle": "同一试验证据披露与结果演进 · 节点=合并后的证据状态",
  "dataSource": "所选记录的临床内容及按输入契约取得的同记录原文；交付时填写实际来源与分析深度",
  "describe": "节点=证据状态或明确里程碑，节点等大等形、不编码成熟度、不渲染图例；证据边界遵守 references/input-contract.md",
  "data": [
    { "time": "2013-12", "label": "研究启动（里程碑）", "content": "启动入组", "description": "" },
    { "time": "2016-08", "label": "早期毒性分析", "content": "早期安全性谱首次披露", "description": "首次安全性信号，成熟度低（随访短、子集小）{{ref_5}}" },
    { "time": "2017-03/2018-12", "label": "pCR 主要分析 · 摘要/主刊", "content": "主要终点首次报告", "description": "同口径重复披露合并；数值一致而统计量有出入{{ref_1}}{{ref_3}}" },
    { "time": "2020-05/2021-05", "label": "3 年 EFS/OS 随访 · 摘要/主刊", "content": "随访更新，新增时间-事件终点", "description": "更新 + 新增终点，成熟度提高；远期毒性信号仍需关注{{ref_2}}{{ref_4}}" }
  ]
}
```

上例是**内容 spec**（不是可交付成品）：`dataSource`/`describe` 会被脚本渲染成 `config.notes`，`language` 决定 notes 标签用「说明：/数据来源：」还是 `Note:`/`Data source:`。把它保存为 `work/charts/evidence-timeline.json` 后跑 `python3 /workspace/skills/multi-clinical-result-comparison/scripts/make_chart.py work/charts/evidence-timeline.json`，成品写入 `/workspace/visualizations/evidence-timeline.json`（**纯 JSON，无 HTML 包裹**）并由脚本跑 `node /workspace/skills/chart-component-layout-json-validation/scripts/validate-cli.js` 校验（exit `0` 才算 PASS）；正文用 `::visualization[标题]{path="/workspace/visualizations/evidence-timeline.json"}` 绝对路径引用，并始终保留精确数值的时间线表格。
