#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Mechanical pre-delivery self-check for the two deliverables and the chart products.

Run this after the render gate and before `present_artifact`.  It only checks things a machine
can settle — text that must not appear, marker/citation parity, chart envelope shape, fixed
paths — so it never replaces clinical review; it stops the run from shipping an unresolved
`[[fact:…]]` token, a chart JSON that is a bare `config` object, a citation key no marker uses,
or a `::visualization` reference pointing at nothing.

The chart envelope is the upstream `chart-component-layout-json-validation` contract:
`{id, version, iframe_template, config}`.  `version` / `iframe_template` change on every chart
publish, so when the runtime chart skill is present the gate compares the product's values with
its `config.js` instead of trusting any cached copy (a stale product is a finding, not a warning).

    python3 /workspace/skills/multi-clinical-result-comparison/scripts/check_report.py
    python3 /workspace/skills/multi-clinical-result-comparison/scripts/check_report.py --report /workspace/output/report.md \
        --citations /workspace/output/citations.json --charts-dir /workspace/visualizations -v

Fixed defaults are the delivery contract paths, so a bare run is the normal case.  Exit codes:
0 nothing fatal (warnings are printed and never change the exit code); 3 at least one finding
(fix before delivering); 2 usage/IO.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

APPENDIX_TITLE = "## 附录：证据对齐矩阵"
MARKER_RE = re.compile(r"\{\{(ref_[1-9]\d*)\}\}")
ANY_BRACE_RE = re.compile(r"\{\{[^{}]*\}\}")
TOKEN_RE = re.compile(r"\[\[\s*(?:fact|result)\s*:")
ENTITY_RE = re.compile(r"\(entity:[^)]*\)|entity:\s*[a-z]+", re.IGNORECASE)
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
VIS_REF_RE = re.compile(r"::visualization\[[^\]]*\]\{([^}]*)\}")
PATH_ATTR_RE = re.compile(r'path\s*=\s*"([^"]+)"')
FENCE_RE = re.compile(r"```")
CHART_TYPE_BY_PREFIX = (("evidence-timeline", "timeline"), ("endpoint-bar-", "bar"), ("endpoint-line-", "line"))
CHART_SKILL_NAME = "chart-component-layout-json-validation"
ENVELOPE_KEYS = {"id", "version", "iframe_template", "config"}
# Fields the upstream skill retired (v0.2.0): the source / reading-aid text now lives in
# `config.notes` as a node array, never as flat strings.
RETIRED_CONFIG_FIELDS = ("dataSource", "describe")
CITATION_FIELDS = ("title", "link", "paper_release_time_str")
EXTERNAL_TITLES = ("## 外部参照", "## External reference")
EXTERNAL_DISCLAIMERS = (
    "外部参照仅用于背景校准，不构成头对头比较。",
    "External references are for background calibration only; they do not constitute a head-to-head comparison.",
)
EXTERNAL_DIFF_KEYS = ("与本组的差异：", "Difference from this set:")
EXTERNAL_USE_KEYS = ("用途：", "Use:")
# The `用途：` value is reader-facing prose: internal question codes (C1–C4) never ship.
EXTERNAL_USE_CODE_RE = re.compile(r"\bC[1-4]\b|C[1-4]\s*类")
EXTERNAL_LIMIT = 6
WATCHLIST_TITLES = ("## 在研同类试验", "## Ongoing same-class trials")
WATCHLIST_DISCLAIMERS = (
    "本段仅登记注册信息，这些试验尚无读出结果，不构成本次比较的证据。",
    "Registered design only; no efficacy or safety results have been read out for these trials, so they "
    "are not evidence in this comparison.",
)
WATCHLIST_STATES = ("listed", "none_alignable", "not_applicable")
WATCHLIST_LIMIT = 5
# A watchlist row states a registry fact. The moment it predicts an outcome it becomes an unrooted
# efficacy claim about a trial nobody has read out, which is exactly what this module must not do.
WATCHLIST_FORECAST_RE = re.compile(
    r"有望|预计(?:获批|上市|读出)|预期(?:优于|获益)|将优于|或将|潜力|威胁|best-in-class|first-in-class"
)
# A ref token is only replaced by the frontend when it is in marker form; a bare `ref_3` renders as
# literal text, which reads as a leaked internal id.
BARE_REF_RE = re.compile(r"(?<!\{)\bref_[1-9]\d*\b(?!\})")
LEAK_PATTERNS = (
    ("source_file", r"source_file"),
    ("tool_results path", r"tool_results"),
    ("internal esid field", r"\besid\b"),
    ("work/ scratch path", r"/workspace/work/"),
    ("ledger file name", r"\b(?:ledger|facts)\.json\b"),
)
# The run-logistics vocabulary is a product rule owned by the evaluator (A-P10); here it is only a
# warning, so a stray word never blocks an otherwise sound delivery mid-run.
RUN_LOGISTICS = (r"本次运行", r"本运行环境", r"运行环境", r"本轮运行", r"无外网", r"网络受限",
                 r"抓取(?:失败|受限|超时)")
# The report states clinical findings; it never narrates its own method, classification or
# bookkeeping.  Labels and chart-decidability wording are the authoring layer's own vocabulary
# (`分析模式`/`选择依据`/`可比性结论`/`对齐等级`/`可绘图`) and they leak the reasoning process into a
# deliverable the reader only wants findings from.  Two slots stay: the fixed non-head-to-head
# caveat and the `原文核对：` coverage line — both written as material statements.
META_LABEL_RE = re.compile(
    r"(?:\*\*|^\s*[-*]\s*)(?:分析模式|分析口径|选择依据|可比性结论|对齐等级|不绘图原因|"
    r"有限并列原因|处理流程|撰写方式|报告结构|检索策略|纳入标准)\s*[:：*]",
    re.MULTILINE)
META_COLUMN_RE = re.compile(
    r"^\s*\|[^\n|]*(?:\|[^\n|]*)*\|\s*(?:对齐等级|分析模式|选择依据|可比性结论|"
    r"不绘图原因|有限并列原因)\s*\|", re.MULTILINE)
METHOD_NARRATION_RE = re.compile(
    r"可绘图|不具备绘图条件|只能有限并列|未生成图表|不生成图表|不生成优效排序|"
    r"本次选择|本次纳入|纳入本次|我们选择|我们纳入|我们取用|本轮|"
    r"(?:部分|直接|仅背景|未)对齐|为便于阅读|便于读者理解")
SELF_AUDIT_RE = re.compile(
    r"无未复核记录|无遗漏记录|无缺失项|无未取回记录|全部通过(?:自检|校验)|"
    r"未发现(?:不一致|问题|异常)|不存在未复核")
INTERNAL_VOCAB_RE = re.compile(r"\bsrc\s*=\s*\d|\bpayload\b|\bJSONL\b|\bMCP\b|沙箱|工作区")
# The deployed timeline renders a plain list: every node the same dot, no legend at all. Text that
# tells the reader about node size / shape / an encoding legend is therefore describing a cue that
# does not exist (R51).
CHART_ENCODING_CLAIM_RE = re.compile(
    r"节点大小|圆点大小|节点权重|权重图例|节点形状|形状编码|大小编码|空心圆|实心圆")
SELF_REFERENCE_RE = re.compile(r"本报告|本文档|本工具|本流程|本管线|本交付物|本次(?!披露)")
CHART_NUMBER_RE = re.compile(r"[-+−]?\d+(?:\.\d+)?")
CHART_UNIT_SUFFIX_RE = re.compile(r"\s*(?:mg/?|周|天|月|年|例|名|岁|nmol/L|mmol/L|每)(?![A-Za-z])", re.IGNORECASE)
# Chart prose must not repeat plotted values; dose/time/count units are allowed context.
# 表格重复只在图表所属正文 section 生效，附录是事实账本，不参与判断。

def _chart_number_tokens(text: str) -> list[tuple[str, float, int]]:
    tokens: list[tuple[str, float, int]] = []
    for match in CHART_NUMBER_RE.finditer(text.replace("−", "-")):
        try:
            tokens.append((match.group(), float(match.group()), match.end()))
        except ValueError:
            continue
    return tokens


def _runtime_envelope(chart_skill: Path) -> dict | None:
    """Read id/version/iframe_template from the deployed chart skill's config.js, if present."""
    try:
        source = (chart_skill / "config.js").read_text(encoding="utf-8")
    except OSError:
        return None

    def literal(name: str) -> str | None:
        match = re.search(rf"^\s*const\s+{name}\s*=\s*'([^']*)'", source, re.MULTILINE)
        return match.group(1) if match else None

    envelope = {"id": literal("SKILL_NAME"), "version": literal("VERSION"),
                "iframe_template": literal("IFRAME_TEMPLATE")}
    return envelope if all(envelope.values()) else None


def _note_texts(notes) -> list[tuple[str, str]]:
    """Flatten the `config.notes` node tree into (path, text) for the label + content nodes."""
    found: list[tuple[str, str]] = []
    if not isinstance(notes, list):
        return found
    for index, node in enumerate(notes):
        if not isinstance(node, dict):
            continue
        for row_index, row in enumerate(node.get("rows") or []):
            if not isinstance(row, dict):
                continue
            for col_index, col in enumerate(row.get("cols") or []):
                if not isinstance(col, dict) or col.get("role") != "note-content":
                    continue
                if isinstance(col.get("markdown"), str):
                    found.append((f"config.notes[{index}].rows[{row_index}].cols[{col_index}]", col["markdown"]))
    return found


def _chart_text_findings(name: str, config: dict) -> list[str]:
    """Return hard findings for plotted values repeated in chart prose."""
    if str(config.get("type") or "").lower() == "timeline":
        return []
    values = [row.get("value") for row in config.get("data", [])
              if isinstance(row, dict) and isinstance(row.get("value"), (int, float))
              and not isinstance(row.get("value"), bool)]
    fields: list[tuple[str, str]] = []
    if isinstance(config.get("subTitle"), str):
        fields.append(("config.subTitle", config["subTitle"]))
    fields.extend(_note_texts(config.get("notes")))
    for index, row in enumerate(config.get("data", [])):
        if isinstance(row, dict) and isinstance(row.get("description"), str):
            fields.append((f"config.data[{index}].description", row["description"]))
    for field, text in fields:
        for token, number, end in _chart_number_tokens(text):
            if "." not in token:
                continue
            if CHART_UNIT_SUFFIX_RE.match(text[end:]):
                continue
            if any(abs(number - value) <= 0.05 for value in values):
                value = next(value for value in values if abs(number - value) <= 0.05)
                return [f"chart {name} {field} restates plotted value {value}; remove the value from the chart text or keep it only in the plot data"]
    return []


def _chart_table_findings(report: str, name: str, config: dict, references: list[re.Match[str]]) -> list[str]:
    """Return hard findings for two plotted values repeated in a non-appendix section table."""
    if str(config.get("type") or "").lower() == "timeline":
        return []
    values = [float(row["value"]) for row in config.get("data", [])
              if isinstance(row, dict) and isinstance(row.get("value"), (int, float))
              and not isinstance(row.get("value"), bool)]
    lines = report.splitlines()
    heading_re = re.compile(r"^(#{1,6})\s+")
    for reference in references:
        line_no = report.count("\n", 0, reference.start())
        heading_index = 0
        heading_level = 0
        heading_text = ""
        for index in range(line_no, -1, -1):
            heading = heading_re.match(lines[index])
            if heading:
                heading_index = index
                heading_level = len(heading.group(1))
                heading_text = lines[index][heading.end():]
                break
        if "附录" in heading_text:
            continue
        end = len(lines)
        for index in range(heading_index + 1, len(lines)):
            heading = heading_re.match(lines[index])
            if heading and (heading_level == 0 or len(heading.group(1)) <= heading_level):
                # heading_level == 0 means the chart sits before the first heading: treat the
                # document head as the section so the appendix can never be counted as a repeat.
                end = index
                break
        matched: set[float] = set()
        for line in lines[heading_index:end]:
            if not line.strip().startswith("|"):
                continue
            for token, number, token_end in _chart_number_tokens(line):
                if CHART_UNIT_SUFFIX_RE.match(line[token_end:]):
                    continue
                for value in values:
                    if abs(number - value) <= 0.05:
                        matched.add(value)
        if len(matched) >= 2:
            displayed = ", ".join(str(value) for value in sorted(matched))
            return [f"chart {name} section table repeats plotted values {displayed}; move the chart to a section without the table or drop the duplicated values"]
    return []


def _appendix_preamble_findings(report: str, max_preamble: int = 100) -> list[str]:
    """The appendix is renderer output: title, one-line `—` legend, then the table.

    A long prose block between the title and the table means the report is carrying a hand-written
    specification of the appendix (or an older renderer's spec paragraph) — the defect that made
    readers scroll past ~600 characters of layout instructions before any data.
    """
    lines = report.splitlines()
    start = next((index for index, line in enumerate(lines) if line.startswith(APPENDIX_TITLE)), None)
    if start is None:
        return []
    for line in lines[start + 1:]:
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("|"):
            return []
        if len(stripped) > max_preamble:
            return [f"the appendix opens with a {len(stripped)}-character prose block instead of the "
                    f"renderer's one-line legend; write no appendix specification paragraph (rows and "
                    f"columns come from the ledger, the title and legend from render-facts.py)"]
        return []
    return []


def _meta_narration_findings(report: str) -> tuple[list[str], list[str]]:
    """Report-about-itself findings: the authoring layer's labels, class and process wording."""
    findings: list[str] = []
    warnings: list[str] = []
    for match in META_LABEL_RE.finditer(report):
        findings.append(f"the report labels its own method ({match.group().strip()!r}); state the finding, "
                        f"not how the report was built")
    for match in META_COLUMN_RE.finditer(report):
        findings.append(f"table column {match.group().strip()!r} is the report classifying its own work; "
                        f"replace the label with the material difference it stands for")
    for label, pattern in (("method/class narration", METHOD_NARRATION_RE),
                           ("self-audit tail", SELF_AUDIT_RE),
                           ("internal field or runtime vocabulary", INTERNAL_VOCAB_RE),
                           ("chart cue that does not exist", CHART_ENCODING_CLAIM_RE)):
        seen: set[str] = set()
        for match in pattern.finditer(report):
            token = match.group()
            if token in seen:
                continue
            seen.add(token)
            findings.append(f"{label} in the deliverable: {token!r}")
    seen = set()
    for match in SELF_REFERENCE_RE.finditer(report):
        token = match.group()
        if token in seen:
            continue
        seen.add(token)
        warnings.append(f"the report refers to itself ({token!r}); write the finding directly")
    return findings, warnings


def _table_cells(report: str) -> list[str]:
    cells: list[str] = []
    for line in report.splitlines():
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        for cell in stripped.strip("|").split("|"):
            cell = cell.strip()
            if cell and set(cell) - set("-: "):
                cells.append(cell)
    return cells


def _refs_by_origin(path: Path, origin: str) -> set[str] | None:
    """Refs marked `origin:<origin>` in the inventory; None when the inventory is unreadable."""
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    return {str(key) for key, entry in data.items()
            if isinstance(entry, dict) and str(entry.get("origin", "")).strip() == origin}


def _external_keys(path: Path) -> set[str] | None:
    return _refs_by_origin(path, "external")


def _watchlist_keys(path: Path) -> set[str] | None:
    return _refs_by_origin(path, "watchlist")


def _external_use_value(line: str) -> str:
    """The text after `用途：` / `Use:` on an entry line, trimmed at the next separator."""
    for key in EXTERNAL_USE_KEYS:
        if key not in line:
            continue
        tail = line.split(key, 1)[1]
        return tail.split("｜", 1)[0].strip().rstrip("。.；;")
    return ""


EXTERNAL_STATES = ("appended", "none_alignable", "not_applicable")


def _external_state_findings(state_file: Path, external: set[str]) -> list[str]:
    """`work/external.json`: the external step happened and ended in one of three states.

    `prep_sources.py --external` writes it, so an absent file means the step never ran. That is the
    hole R78 exposed: three runs skipped the default lookup entirely, said nothing in the report (by
    contract), and passed every gate — silence was indistinguishable from "ran, nothing alignable".
    """
    if not state_file.is_file():
        return [f"no external-step record at {state_file} — run prep_sources.py --external (append what you "
                "will cite), --none-found (nothing alignable) or --not-applicable --reason (does not apply)"]
    try:
        payload = json.loads(state_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"external-step record at {state_file} is unreadable: {exc}"]
    if not isinstance(payload, dict):
        return [f"external-step record at {state_file} is not an object"]
    state = str(payload.get("state", "")).strip()
    findings: list[str] = []
    if state not in EXTERNAL_STATES:
        findings.append(f"external-step state {state!r} is not one of {', '.join(EXTERNAL_STATES)}")
        return findings
    if state == "not_applicable":
        if len(str(payload.get("reason", "")).strip()) < 8:
            findings.append("external step marked not_applicable without a reason — say why the lookup does "
                            "not apply here")
        if external:
            findings.append(f"external step marked not_applicable yet the inventory holds {len(external)} "
                            "origin=external entr(ies)")
    elif state == "none_alignable":
        if external:
            findings.append(f"external step recorded none_alignable yet {len(external)} origin=external "
                            "entr(ies) are in the inventory")
    else:  # appended
        if not external:
            findings.append("external step recorded appended but the inventory holds no origin=external entry")
        added = payload.get("refs_added")
        if not isinstance(added, list) or not added:
            findings.append("external step recorded appended without naming the refs it added")
    return findings



def _watchlist_state_findings(state_file: Path, watchlist: set[str]) -> list[str]:
    """`work/watchlist.json`: the ongoing-trials step happened and ended in one of three states.

    Same lesson as `work/external.json` (R78): the step's normal outcome is a silent section, so
    without a record "never ran" and "ran, nothing to list" are indistinguishable, and the free path
    is to skip it. The record makes the outcome reviewable.
    """
    if not state_file.is_file():
        return [f"no ongoing-trials record at {state_file} — run trial_watchlist.py (--append with the kept "
                "rows, --none-found when nothing qualifies, or --not-applicable --reason)"]
    try:
        payload = json.loads(state_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"ongoing-trials record at {state_file} is unreadable: {exc}"]
    if not isinstance(payload, dict):
        return [f"ongoing-trials record at {state_file} is not an object"]
    state = str(payload.get("state", "")).strip()
    findings: list[str] = []
    if state not in WATCHLIST_STATES:
        findings.append(f"ongoing-trials state {state!r} is not one of {', '.join(WATCHLIST_STATES)}")
        return findings
    rows = payload.get("trials")
    row_count = len(rows) if isinstance(rows, list) else 0
    if state == "not_applicable":
        if len(str(payload.get("reason", "")).strip()) < 8:
            findings.append("ongoing-trials step marked not_applicable without a reason — say why the lookup "
                            "does not apply here")
        if watchlist:
            findings.append(f"ongoing-trials step marked not_applicable yet the inventory holds "
                            f"{len(watchlist)} origin=watchlist entr(ies)")
    elif state == "none_alignable":
        if watchlist:
            findings.append(f"ongoing-trials step recorded none_alignable yet {len(watchlist)} "
                            "origin=watchlist entr(ies) are in the inventory")
    else:  # listed
        if not watchlist:
            findings.append("ongoing-trials step recorded listed but the inventory holds no origin=watchlist "
                            "entry")
        added = payload.get("refs_added")
        if not isinstance(added, list) or not added:
            findings.append("ongoing-trials step recorded listed without naming the refs it added")
        elif set(added) != watchlist:
            findings.append(f"ongoing-trials record names {sorted(added)} but the inventory holds "
                            f"{sorted(watchlist)} as origin=watchlist")
        if row_count > WATCHLIST_LIMIT:
            findings.append(f"{row_count} ongoing trial(s) recorded, over the budget of {WATCHLIST_LIMIT}")
    return findings


def _watchlist_section_findings(report: str, watchlist: set[str]) -> list[str]:
    """The ongoing-same-class block: registry facts only, one place, never evidence."""
    findings: list[str] = []
    lines = report.splitlines()
    label = WATCHLIST_TITLES[0]
    titles = [index for index, line in enumerate(lines) if any(line.startswith(p) for p in WATCHLIST_TITLES)]
    cited = watchlist & set(MARKER_RE.findall(report))
    if len(titles) > 1:
        findings.append(f"`{label}` appears {len(titles)} times — one block only")
    if cited and not titles:
        findings.append(f"ongoing-trial marker cited but the `{label}（尚未读出）` section is missing")
    if titles and not cited:
        findings.append(f"`{label}` section present but no origin=watchlist marker is used — drop the section "
                        "or name the trial it lists")
    if watchlist and not cited:
        findings.append(f"{len(watchlist)} ongoing trial(s) were appended to the inventory "
                        f"({', '.join(sorted(watchlist)[:3])}) but none is cited — cite it in the section, "
                        "or do not append it")
    start = titles[0] if titles else None
    if start is not None:
        end = len(lines)
        for index in range(start + 1, len(lines)):
            if lines[index].startswith("## "):
                end = index
                break
        block = lines[start + 1:end]
        if not any(line.strip() in WATCHLIST_DISCLAIMERS for line in block):
            findings.append(f"`{label}` must open with the fixed line `{WATCHLIST_DISCLAIMERS[0]}` "
                            "(or its English counterpart — no paraphrase)")
        named = [mark for mark in MARKER_RE.findall("\n".join(block)) if mark in watchlist]
        if len(set(named)) > WATCHLIST_LIMIT:
            findings.append(f"{len(set(named))} trials listed in one block exceeds the budget of "
                            f"{WATCHLIST_LIMIT}")
        for line in block:
            hit = WATCHLIST_FORECAST_RE.search(line)
            if hit:
                findings.append(f"ongoing-trials section predicts an outcome ({hit.group()!r}) — this section "
                                "records registration facts, it never forecasts a readout")
        appendix = next((index for index, line in enumerate(lines) if line.startswith(APPENDIX_TITLE)), None)
        if appendix is not None and start > appendix:
            findings.append(f"`{label}` sits inside or after the appendix — it belongs in the body, before the "
                            "closing interpretation")
        conclusion = next((index for index, line in enumerate(lines)
                           if index > start and re.match(r"#{2,3}\s*(?:[一二三四五六七八九十]+、)?\s*"
                                                        r"(?:结论|综合解读|总体解读|Conclusion)", line)), None)
        if conclusion is None:
            findings.append(f"`{label}` has no closing interpretation section after it — keep the block before "
                            "the report's final interpretation")
    for index, line in enumerate(lines):
        for mark in MARKER_RE.findall(line):
            if mark not in watchlist:
                continue
            if line.lstrip().startswith("|") and (start is None or index < start):
                findings.append(f"ongoing-trial marker {{{{{mark}}}}} on a table line ({index + 1}) outside its "
                                "own section — a still-running trial never enters a comparison table")
            elif start is None or index < start:
                findings.append(f"ongoing-trial marker {{{{{mark}}}}} before the `{label}` section ({index + 1})")
    return findings


def _external_reference_findings(report: str, external: set[str]) -> list[str]:
    """The bounded external-reference block: one place, fixed wording, never a table cell."""
    findings: list[str] = []
    lines = report.splitlines()
    label = EXTERNAL_TITLES[0]
    titles = [index for index, line in enumerate(lines) if any(line.startswith(p) for p in EXTERNAL_TITLES)]
    cited = external & set(MARKER_RE.findall(report))
    if len(titles) > 1:
        findings.append(f"`{label}` appears {len(titles)} times — one bounded block only")
    if cited and not titles:
        findings.append(f"external reference cited but the `{label}（非所选记录）` section is missing")
    if titles and not cited:
        findings.append(f"`{label}` section present but no origin=external marker is used — "
                        "drop the section or name the reference it holds")
    if external and not cited:
        findings.append(f"{len(external)} external reference(s) were appended to the inventory "
                        f"({', '.join(sorted(external)[:3])}) but none is cited — an appended source is "
                        "a claim that it belongs in the deliverable: cite it in the block, or do not pull it")
    start = titles[0] if titles else None
    if start is not None:
        end = len(lines)
        for index in range(start + 1, len(lines)):
            if lines[index].startswith("## "):
                end = index
                break
        block = lines[start + 1:end]
        if not any(line.strip() in EXTERNAL_DISCLAIMERS for line in block):
            findings.append(f"`{label}` must open with the fixed line `{EXTERNAL_DISCLAIMERS[0]}` "
                            "(or its English counterpart — no paraphrase)")
        named: set[str] = set()
        for line in block:
            if not line.lstrip().startswith("- "):
                continue
            marks = [mark for mark in MARKER_RE.findall(line) if mark in external]
            if len(marks) != 1:
                findings.append("external entry line must carry exactly one origin=external marker: "
                                + line.strip()[:60])
            named.update(marks)
            if not any(key in line for key in EXTERNAL_DIFF_KEYS):
                findings.append(f"external entry line is missing `{EXTERNAL_DIFF_KEYS[0]}`: "
                                + line.strip()[:60])
            if not any(key in line for key in EXTERNAL_USE_KEYS):
                findings.append(f"external entry line is missing `{EXTERNAL_USE_KEYS[0]}`: "
                                + line.strip()[:60])
            else:
                use = _external_use_value(line)
                if not use:
                    findings.append("external entry line has an empty `用途：` value: " + line.strip()[:60])
                elif EXTERNAL_USE_CODE_RE.search(use):
                    findings.append("external `用途：` reads as an internal question code "
                                    f"({use[:24]!r}) — say what the reference is for in plain words")
        if cited - named:
            findings.append(f"external marker(s) with no entry line of their own: {sorted(cited - named)}")
        if len(named) > EXTERNAL_LIMIT:
            findings.append(f"{len(named)} external source(s) in one block exceeds the budget of {EXTERNAL_LIMIT}")
    for index, line in enumerate(lines):
        for mark in MARKER_RE.findall(line):
            if mark not in external:
                continue
            if line.lstrip().startswith("|"):
                findings.append(f"external marker {{{{{mark}}}}} on a table line ({index + 1}) — external values stay "
                                "out of the comparison tables and the appendix")
            elif start is None or index < start:
                findings.append(f"external marker {{{{{mark}}}}} before the `{label}` section ({index + 1})")
    return findings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Mechanical pre-delivery checks for report.md, citations.json and /workspace/visualizations/*.json",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--report", type=Path, default=Path("/workspace/output/report.md"))
    parser.add_argument("--citations", type=Path, default=Path("/workspace/output/citations.json"))
    parser.add_argument("--charts-dir", type=Path, default=Path("/workspace/visualizations"))
    parser.add_argument("--refs", type=Path, default=Path("/workspace/work/refs.json"),
                        help="ref inventory; its origin:external entries define the bounded external-reference set")
    parser.add_argument("--external-state", type=Path,
                        help="record of the external step's outcome (default: <refs dir>/external.json)")
    parser.add_argument("--watchlist-state", type=Path,
                        help="record of the ongoing-trials step's outcome (default: <refs dir>/watchlist.json)")
    parser.add_argument("--chart-skill", type=Path, default=Path(f"/workspace/skills/{CHART_SKILL_NAME}"),
                        help="deployed chart skill; its config.js is the envelope authority when present")
    parser.add_argument("--vis-prefix", default="/workspace/visualizations/",
                        help="required prefix of a ::visualization target (fixed at /workspace/visualizations/ "
                             "in the runtime; overridable only for a mirrored/test layout)")
    parser.add_argument("--json", action="store_true", help="print a machine-readable result")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    findings: list[str] = []
    warnings: list[str] = []
    checks: list[tuple[str, str]] = []

    if not args.report.is_file():
        print(f"FAIL: report missing: {args.report}", file=sys.stderr)
        return 3
    report = args.report.read_text(encoding="utf-8", errors="replace")
    if not report.strip():
        print(f"FAIL: report is empty: {args.report}", file=sys.stderr)
        return 3

    # ---- report text invariants -------------------------------------------------------
    tokens = TOKEN_RE.findall(report)
    if tokens:
        sample = re.findall(r"\[\[\s*(?:fact|result)\s*:[^\]]*\]\]", report)[:3]
        findings.append(f"unresolved fact/result token(s) in the report: {sample}")
    braces = set(ANY_BRACE_RE.findall(report)) - {f"{{{{{ref}}}}}" for ref in MARKER_RE.findall(report)}
    braces = {item for item in braces if item not in {"{{APPENDIX}}", "{{appendix}}"}}
    if braces:
        findings.append(f"placeholder braces that are not {{ref_n}} markers: {sorted(braces)[:5]}")
    bare_refs = [
        (number, BARE_REF_RE.findall(line)[0])
        for number, line in enumerate(report.splitlines(), start=1)
        if BARE_REF_RE.search(line)
    ]
    if bare_refs:
        sample = ", ".join(f"{token} on line {number}" for number, token in bare_refs[:5])
        findings.append(
            f"bare ref token(s) not in marker form: {sample} — the frontend replaces {{{{ref_n}}}}, "
            "a bare ref_n is shown to the reader as raw text"
        )
    if ENTITY_RE.search(report):
        findings.append("`entity:` inline-reference syntax present (removed in v0.16, fails closed)")
    appendix_lines = [line for line in report.splitlines() if line.startswith(APPENDIX_TITLE)]
    if not appendix_lines:
        findings.append(f"appendix title `{APPENDIX_TITLE}` not found (the render gate appends it)")
    else:
        if len(appendix_lines) > 1:
            findings.append(f"appendix title appears {len(appendix_lines)} times — the appendix is renderer output; "
                            "write no appendix of your own and never render the same file twice")
        findings.extend(_appendix_preamble_findings(report))
    appendix_rows = 0
    if appendix_lines:
        start = report.index(appendix_lines[0])
        for line in report[start:].splitlines():
            if line.strip().startswith("|") and "---" not in line:
                appendix_rows += 1
        if appendix_rows <= 1:
            findings.append("appendix carries no data row (header only)")
    for label, pattern in LEAK_PATTERNS:
        hit = re.search(pattern, report)
        if hit:
            line_no = report.count("\n", 0, hit.start()) + 1
            findings.append(f"{label} leaked into the report at line {line_no}: {hit.group()!r}")
    for pattern in RUN_LOGISTICS:
        hit = re.search(pattern, report)
        if hit:
            warnings.append(f"run-logistics wording in the deliverable (A-P10): {hit.group()!r}")
    meta_findings, meta_warnings = _meta_narration_findings(report)
    findings.extend(meta_findings)
    warnings.extend(meta_warnings)
    checks.append(("report voice", "findings only — no method/class/self-audit narration"))
    if re.search(r"```\s*mermaid", report, re.IGNORECASE):
        findings.append("Mermaid block emitted; the delivery channel is chart JSON + ::visualization only")
    checks.append(("report text", "tokens/markers/entity/appendix"))

    # ---- markers vs citations --------------------------------------------------------
    markers = set(MARKER_RE.findall(report))
    citations: dict = {}
    if not args.citations.is_file():
        findings.append(f"citation file missing: {args.citations}")
    else:
        raw = args.citations.read_text(encoding="utf-8", errors="replace")
        text = raw.strip()
        if text.startswith("```") or not text.startswith("{"):
            findings.append("citation file is fenced or not raw JSON; it must be one unfenced JSON object")
        else:
            try:
                citations = json.loads(text)
            except json.JSONDecodeError as exc:
                findings.append(f"citation file is not valid JSON: {exc}")
        if not isinstance(citations, dict):
            findings.append("citation JSON must be an object keyed by ref_n")
            citations = {}
        for key, entry in sorted(citations.items()):
            if not re.fullmatch(r"ref_[1-9]\d*", str(key)):
                findings.append(f"citation key {key!r} is not a ref_n marker")
                continue
            if not isinstance(entry, dict):
                findings.append(f"{key}: citation entry is not an object")
                continue
            extra = sorted(set(entry) - set(CITATION_FIELDS))
            missing = [field for field in CITATION_FIELDS if field not in entry]
            if missing:
                findings.append(f"{key}: citation entry missing {missing}")
            if extra:
                findings.append(f"{key}: citation entry has extra fields {extra}")
            title = entry.get("title")
            link = entry.get("link")
            stamp = entry.get("paper_release_time_str")
            if not isinstance(title, str) or not title.strip():
                findings.append(f"{key}: empty title — a record that never came back must not be cited")
            if not isinstance(link, str) or not link.strip():
                findings.append(f"{key}: empty link")
            if not isinstance(stamp, str):
                findings.append(f"{key}: paper_release_time_str must be a string")
            elif stamp and not DATE_RE.match(stamp):
                findings.append(f"{key}: paper_release_time_str must be YYYY-MM-DD or empty (got {stamp!r})")
        keys = set(citations)
        if markers - keys:
            findings.append(f"markers without a citation key: {sorted(markers - keys)}")
        if keys - markers:
            findings.append(f"citation keys never used in the report: {sorted(keys - markers)}")
        if ENTITY_RE.search(json.dumps(citations, ensure_ascii=False)):
            findings.append("`entity:` syntax present in the citation JSON")
        checks.append(("markers vs citations", f"{len(markers)} marker(s) / {len(keys)} key(s)"))

    # ---- bounded external reference ------------------------------------------------
    external = _external_keys(args.refs)
    state_file = args.external_state or (args.refs.parent / "external.json")
    if external is None:
        warnings.append(f"external-reference placement not checked: no readable ref inventory at {args.refs}")
    else:
        findings.extend(_external_state_findings(state_file, external))
        if state_file.is_file():
            try:
                state_payload = json.loads(state_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                state_payload = {}
            checks.append(("external step",
                           f"state={state_payload.get('state')} question={state_payload.get('question')} "
                           f"added={len(state_payload.get('refs_added') or [])}"))
        findings.extend(_external_reference_findings(report, external))
        cited_external = external & set(MARKER_RE.findall(report))
        checks.append(("external references",
                       f"{len(cited_external)}/{len(external)} origin=external entr(ies) cited, placement checked"))

    # ---- ongoing same-class trials (never evidence) ----------------------------------
    watchlist = _watchlist_keys(args.refs)
    wl_state = getattr(args, "watchlist_state", None) or (args.refs.parent / "watchlist.json")
    if watchlist is None:
        warnings.append(f"ongoing-trials placement not checked: no readable ref inventory at {args.refs}")
    else:
        findings.extend(_watchlist_state_findings(wl_state, watchlist))
        if wl_state.is_file():
            try:
                wl_payload = json.loads(wl_state.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                wl_payload = {}
            rows = wl_payload.get("trials")
            checks.append(("ongoing trials",
                           f"state={wl_payload.get('state')} listed={len(rows) if isinstance(rows, list) else 0} "
                           f"added={len(wl_payload.get('refs_added') or [])}"))
        findings.extend(_watchlist_section_findings(report, watchlist))
        cited_wl = watchlist & set(MARKER_RE.findall(report))
        checks.append(("ongoing trials section",
                       f"{len(cited_wl)}/{len(watchlist)} origin=watchlist entr(ies) cited, placement checked"))

    # ---- chart products --------------------------------------------------------------
    charts: dict[str, dict] = {}
    referenced: list[str] = []
    for match in VIS_REF_RE.finditer(report):
        path_match = PATH_ATTR_RE.search(match.group(1))
        if not path_match:
            findings.append(f"::visualization reference without a path attribute: {match.group(0)[:80]}")
            continue
        target = path_match.group(1)
        referenced.append(target)
        if not target.endswith(".json"):
            findings.append(f"::visualization target is not a .json file: {target}")
        if not target.startswith(args.vis_prefix):
            findings.append(f"::visualization target is outside the固定 prefix: {target}")
        if not Path(target).is_file():
            findings.append(f"::visualization target does not exist: {target}")
    if args.charts_dir.is_dir():
        runtime_envelope = _runtime_envelope(args.chart_skill)
        if runtime_envelope is None:
            warnings.append(f"deployed chart skill not readable at {args.chart_skill}; envelope version/"
                            f"iframe_template cannot be cross-checked against it")
        for path in sorted(args.charts_dir.glob("*.json")):
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                findings.append(f"{path.name}: not valid JSON ({exc})")
                continue
            if not isinstance(payload, dict):
                findings.append(f"{path.name}: chart product is not an object")
                continue
            charts[path.name] = payload
            if set(payload) != ENVELOPE_KEYS:
                findings.append(f"{path.name}: envelope keys must be exactly id/version/iframe_template/config "
                                f"(got {sorted(payload)}) — a bare config object is invalid")
                continue
            if payload.get("id") != CHART_SKILL_NAME:
                findings.append(f"{path.name}: envelope id must be {CHART_SKILL_NAME!r} "
                                f"(got {payload.get('id')!r}); the retired chart-visualization-json envelope "
                                f"is not accepted")
            if not str(payload.get("version") or "").strip():
                findings.append(f"{path.name}: empty version (it is refreshed on every chart publish)")
            if not str(payload.get("iframe_template") or "").strip():
                findings.append(f"{path.name}: empty iframe_template (it is refreshed on every chart publish)")
            for field in ("version", "iframe_template"):
                expected = (runtime_envelope or {}).get(field)
                if expected and payload.get(field) != expected:
                    findings.append(f"{path.name}: {field} does not match the deployed chart skill "
                                    f"({payload.get(field)!r} != {expected!r}) — rebuild it with scripts/make_chart.py")
            config = payload.get("config")
            if not isinstance(config, dict):
                findings.append(f"{path.name}: config must be an object")
                continue
            if config.get("kind") != "chart":
                findings.append(f"{path.name}: config.kind must be 'chart' (got {config.get('kind')!r})")
            retired = [field for field in RETIRED_CONFIG_FIELDS if field in config]
            if retired:
                findings.append(f"{path.name}: {', '.join('config.' + field for field in retired)} retired by "
                                f"the upstream chart skill — move that text into config.notes source-note rows "
                                f"(scripts/make_chart.py does this from the spec's description/dataSource)")
            chart_type = str(config.get("type") or "").lower()
            expected_type = next((kind for prefix, kind in CHART_TYPE_BY_PREFIX if path.name.startswith(prefix)), None)
            if expected_type is None:
                warnings.append(f"{path.name}: file name is outside the fixed product names")
            elif chart_type != expected_type:
                findings.append(f"{path.name}: config.type is {chart_type!r}, expected {expected_type!r}")
            data = config.get("data")
            if not isinstance(data, list) or not data:
                findings.append(f"{path.name}: config.data is empty — an empty chart is not a deliverable")
                continue
            for index, row in enumerate(data):
                if not isinstance(row, dict):
                    findings.append(f"{path.name}.data[{index}]: not an object")
                    continue
                if chart_type == "timeline":
                    if not str(row.get("time") or "").strip():
                        findings.append(f"{path.name}.data[{index}]: missing time anchor")
                    if not str(row.get("description") or "").strip():
                        findings.append(f"{path.name}.data[{index}]: empty description")
                    if row.get("weight") is not None:
                        findings.append(
                            f"{path.name}.data[{index}]: `weight` is dead — the deployed timeline renders "
                            "every node the same, so state the maturity judgement in the node description and "
                            "the report text instead")
                    if row.get("shape") is not None:
                        findings.append(
                            f"{path.name}.data[{index}]: node `shape` is dead — the deployed timeline does "
                            "not shape-code nodes; write the category in the label/content text")
                else:
                    if not str(row.get("label") or "").strip():
                        findings.append(f"{path.name}.data[{index}]: empty label")
                    if not isinstance(row.get("value"), (int, float)) or isinstance(row.get("value"), bool):
                        findings.append(f"{path.name}.data[{index}]: value is not numeric")
                    if not str(row.get("description") or "").strip():
                        findings.append(f"{path.name}.data[{index}]: empty description")
            if chart_type == "timeline" and config.get("weightLegend") is not None:
                findings.append(
                    f"{path.name}: `weightLegend` is no longer rendered by the timeline chart — drop it and "
                    "state the maturity judgement in text")
            if chart_type == "timeline" and config.get("legend") is not None:
                findings.append(
                    f"{path.name}: the timeline chart renders no legend — `legend` would imply a "
                    "category/shape encoding that does not exist; drop it and name each state's category in "
                    "its label/content text")
            if ENTITY_RE.search(json.dumps(payload, ensure_ascii=False)):
                findings.append(f"{path.name}: `entity:` syntax present in the chart JSON")
            if re.search(r"<html|<svg|<div", json.dumps(payload), re.IGNORECASE):
                findings.append(f"{path.name}: contains markup; chart products are pure JSON")
        unused_charts = sorted(set(charts) - {Path(item).name for item in referenced})
        if unused_charts:
            warnings.append(f"chart product(s) never referenced by the report: {unused_charts}")
    else:
        warnings.append(f"no chart directory at {args.charts_dir}")
    checks.append(("chart products", f"{len(charts)} file(s), {len(referenced)} reference(s)"))

    # Hard chart-duplication rules run only for referenced chart products.
    for name, payload in charts.items():
        config = payload.get("config")
        if not isinstance(config, dict) or name not in {Path(item).name for item in referenced}:
            continue
        findings.extend(_chart_text_findings(name, config))
        chart_refs = []
        for match in VIS_REF_RE.finditer(report):
            path_match = PATH_ATTR_RE.search(match.group(1))
            if path_match and Path(path_match.group(1)).name == name:
                chart_refs.append(match)
        findings.extend(_chart_table_findings(report, name, config, chart_refs))

    # ---- soft content checks ---------------------------------------------------------
    for cell in _table_cells(report):
        refs = MARKER_RE.findall(cell)
        if len(refs) != len(set(refs)):
            warnings.append(f"table cell cites the same ref more than once: {cell[:60]!r}")

    if args.json:
        print(json.dumps({"findings": findings, "warnings": warnings, "checks": checks}, ensure_ascii=False))
    else:
        if args.verbose:
            for name, note in checks:
                print(f"  ok: {name} — {note}")
        for item in findings:
            print(f"FAIL: {item}")
        for item in warnings:
            print(f"WARN: {item}")
        if not findings:
            print(f"PASS: {len(checks)} check group(s) green"
                  + (f", {len(warnings)} warning(s)" if warnings else "")
                  + f" — report {len(report.encode('utf-8'))} B, {len(markers)} marker(s), "
                    f"{len(charts)} chart file(s)")
    # Findings fail closed (the product is broken).  Warnings never change the exit code: a warning
    # is a note for the operator, and a non-zero exit here costs the model a whole turn on an
    # advisory.  See the two-level doctrine in references/toolbox.md.
    if findings:
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
