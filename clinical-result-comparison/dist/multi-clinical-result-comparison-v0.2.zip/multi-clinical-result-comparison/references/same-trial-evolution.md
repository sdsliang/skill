# Same-Trial Evidence Evolution

## Goal

Reconstruct how evidence from one trial changed across selected disclosures. The objects being compared are evidence states, not competing treatments or publications.

## Step 1: Establish the common trial core

Confirm the shared trial identity, population, randomized arms, and principal study design. Note separate cohorts, extensions, substudies, and post hoc analyses instead of merging them into the core population.

## Step 2: Build an evidence chronology

Order disclosures using, in priority order:

1. data cutoff;
2. stated follow-up duration;
3. analysis milestone such as interim/final/planned analysis;
4. disclosure/publication date.

Database order and record update time are not clinical maturity evidence. If dates conflict or are missing, show an uncertain chronology rather than guessing.

## Step 3: Classify disclosure relationships

For each later evidence item relative to earlier items, use one or more labels:

- **Duplicate**: materially the same analysis and data, republished or re-presented.
- **Update**: later cutoff/follow-up or a refreshed estimate of an existing endpoint.
- **New endpoint**: adds an endpoint not previously mature or disclosed.
- **Confirmation**: independently reported later evidence supports the prior direction without merely duplicating it.
- **Complement**: adds subgroup, safety, quality-of-life, PK/PD, or methodological detail.
- **Supersedes**: a later analysis should replace an earlier estimate for the same endpoint and population.
- **Conflict**: values, populations, or interpretations disagree and cannot be reconciled from the supplied text.

Do not call repeated conference and journal reporting “confirmation” when both use the same cutoff and analysis.

## Step 4: Align endpoint versions

For every important endpoint, show:

- earliest disclosed state;
- later state;
- cutoff/follow-up change;
- estimate and uncertainty change;
- whether statistical status changed;
- whether the analysis population changed;
- interpretation of the change.

Do not compare subgroup medians to overall medians as temporal updates. Do not treat `NR` to a numeric median as worsening or improvement without considering event accumulation and endpoint direction.

## Step 5: Assess maturity changes

Describe maturity through concrete evidence:

- longer follow-up;
- more events;
- prespecified analysis reached;
- confidence interval narrowed or boundary crossed;
- time-to-event endpoint became estimable;
- additional safety exposure;
- durability established or weakened;
- primary findings corroborated by later endpoints;
- unresolved missing data or new inconsistency.

Avoid a generic maturity score when the concrete change is more informative.

## Step 6: State whether the trial interpretation changed

Use one of these outcomes:

- **Strengthened**: later evidence materially increases confidence or adds decision-relevant benefit.
- **Broadly unchanged**: later evidence adds detail but does not materially alter the main interpretation.
- **Qualified**: later evidence preserves part of the signal but introduces important limitations or trade-offs.
- **Weakened**: later evidence reduces confidence or contradicts an earlier favorable interpretation.
- **Indeterminate**: source gaps or conflicts prevent a defensible direction.

State exactly which new evidence caused the classification.

## Required deep-analysis topics

- common trial identity and any cohort boundaries;
- evidence chronology;
- duplicate versus genuinely new evidence;
- endpoint-by-endpoint changes;
- efficacy maturity;
- safety maturity;
- newly introduced limitations or conflicts;
- net change in trial interpretation.
